const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const {responseError, responseSuccess} = require('../../helper/responce')
const axios = require('axios');
const zeroPad = (num, places) => String(num).padStart(places, '0')

exports.createLeadVisit = async (req, res) => {
    try {
      // Destructuring request body
      let { lead_id, p_visit_date, p_visit_time, current_date } = req.body;
      let sales_visit_id = ''
      // Check if lead exists
      let visitData = await req.config.leads.findByPk(lead_id);
      if (!visitData) return await responseError(req, res, "No visit found!");
  
      // Get the last visit for the lead
      let lastVisit = await req.config.leadVisit.findOne({
        where: { lead_id },
        order: [["lead_id", "DESC"]],
        limit: 1
      });
  
      // Count total visits (including soft-deleted ones)
      let visitCount = await req.config.leadVisit.count({ paranoid: false });
  
      // If no previous visit, proceed to create a new visit
      if (!lastVisit) {
        // Sync visit with Salesforce

        const fetchAccessToken = async (retries = 3) => {
          const fetch = (await import('node-fetch')).default;
          const url = "https://test.salesforce.com/services/oauth2/token";
          const params = new URLSearchParams({
            username: "admin@saleofast.com.postsales",
            password: "Kloudrac@123vYX98EkG31lg5Px0ZnL7htFFa",
            grant_type: "password",
            client_id: "3MVG9Po2PmyYruunGgi2prNyVV6tkMw2sEKnTxnl__qXGx8UtKhsi7cKL8WnfdaCyy9d7q5yB5slQkjvL3jvS",
            client_secret: "11B5983495743D8DBA34CC3B5D12FAD8F0F11106ED19A7E00A01403F7942195E"
          });
    
          const requestOptions = {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: params.toString(),
            redirect: "follow"
          };
    
          for (let attempt = 1; attempt <= retries; attempt++) {
            try {
              const response = await fetch(url, requestOptions);
              if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
              }
              return await response.json(); // Assuming the response is JSON
            } catch (error) {
              if (attempt < retries) {
                console.log(`Retry attempt ${attempt} failed. Retrying...`);
                await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
              } else {
                throw error;
              }
            }
          }
        };
  
        const tokenResponse = await fetchAccessToken();

        if(tokenResponse && tokenResponse.access_token ){
          let salesforceData = JSON.stringify({
            "Subject__c": "Site Visit",
            "Visit_Type_pklst__c": "Site Visit",
            "Customer_Name__c": visitData.lead_name,
            "Phone_Number__c": visitData.p_contact_no,
            "StartDateTime__c": `${visitData.p_visit_date}T${visitData.p_visit_time}Z`,
            "EndDateTime__c": "2024-05-31T12:00:00Z",
            "Remarks__c": "",
            "CLeads__c": visitData.sales_lead_id
          });
  
          let configLead = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://saleofast--postsales.sandbox.my.salesforce.com/services/data/v56.0/sobjects/Event_Request__c',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${tokenResponse.access_token}`,
            },
            data: salesforceData
          };
  
          axios.request(configLead)
            .then(response => {
              sales_visit_id = response.data.id;
                 // Insert the lead data into the database
                 req.config.leadVisit.create({
                  lead_id,
                  p_visit_date,
                  p_visit_time,
                  sales_visit_id: response.data.id,
                  visit_code: `${req.admin.user.charAt(0).toUpperCase()}${req.admin.user_l_name ? req.admin.user_l_name.charAt(0).toUpperCase() : ''}V_${zeroPad(visitCount + 1, 5)} `
                }).then(async (visitData) => {
              return await responseSuccess(req, res, "Visit created successfully", visitData);
            }).catch((error) => {
              console.error("Error creating lead:", error);
              return  responseError(req, res, "Something went wrong while creating the lead");
            });
          }).catch((error) => {
            console.error("Error creating lead:", error);
            return  responseError(req, res, "Something went wrong while creating the lead");
          });
           // Create a new visit in the local database

          // after create visit  update lead stage
          await visitData.update({
            lead_stg_id : 2
          })
    
        }else{
          return await responseError(req, res, "token genration failed",tokenResponse);

        }
  
  
  
       
      
      } else {
        // Check if the last visit was completed within the last 90 days
        if (lastVisit.status === 'Completed') {
          return await responseError(req, res, "Cannot request visit. Last visit completed within 90 days");
        }
  
        // Check if the last visit was requested within the last 24 hours
        let dateTime = new Date(lastVisit.createdAt);
        dateTime.setHours(dateTime.getHours() + 24);
        if (lastVisit.status !== 'Completed' && dateTime > new Date(current_date)) {
          return await responseError(req, res, "Cannot request visit. Last visit requested within 24 hours");
        }
  
        // Create a new visit in the local database
        let newVisit = await req.config.leadVisit.create({
          lead_id,
          p_visit_date,
          p_visit_time,
          visit_code: `${req.admin.user.charAt(0).toUpperCase()}${req.admin.user_l_name ? req.admin.user_l_name.charAt(0).toUpperCase() : ''}V_${zeroPad(visitCount + 1, 5)}`
        });

         // after create visit  update lead stage
         await visitData.update({
          lead_stg_id : 2
        })
  
        return await responseSuccess(req, res, "Visit requested successfully", newVisit);
      }
  
    } catch (error) {
      console.error("Error:", error);
      return await responseError(req, res, "Something went wrong");
    }
  };



exports.getleadsVisit = async(req, res) =>{
    try {
        let visitData;
        let whereClause = {};
        if(req.query.f_date){
            whereClause.createdAt = {
              [Op.gte]: req.query.f_date, // Greater than or equal to current date at midnight
              [Op.lt]:  req.query.t_date// Less than current date + 1 day at midnight
          }
        }
        if(!req.query.visit_id) {
            visitData = await req.config.leadVisit.findAll({
                where: {
                    ...whereClause,

                },
                include: [
                    {
                      model: req.config.leads,
                      as: 'leadData',
                      where: {
                        assigned_lead: req.user.user_id
                      },
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },
                      required:true,

                      include : [
                        {
                          model: req.config.channelProject,
                          as: 'projectData',
                          attributes: {
                            exclude: ["createdAt", "updatedAt", "deletedAt"],
                          },
                        },
                       
                        ]
                    }, 
                   
                  ],
                  order: [["visit_id", "DESC"]],
            })
        }else{
            visitData = await req.config.leadVisit.findByPk(req.query.visit_id, {
                include: [
                    {
                      model: req.config.leads,
                      as: 'leadData',
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },

                      include : [
                        {
                          model: req.config.channelProject,
                          as: 'projectData',
                          attributes: {
                            exclude: ["createdAt", "updatedAt", "deletedAt"],
                          },
                        },
                       
                        ]
                    }, 
                   
                  ],
            })
        }
        
        return await responseSuccess(req, res, "visitData list", visitData)
       
    } catch (error) {
        console.log("error", error)
        return await responseError(req, res, "leadList fetching failed", error)
    }
}




exports.editleadsVisit = async(req, res) =>{
    try {

        let {visit_id, p_visit_date, p_visit_time, lead_id} = req.body
        let body = req.body

        let visitData = await req.config.leadVisit.findByPk(visit_id)
        if(!visitData) return await responseError(req, res, "no visit existed") 

        let visitDuplicateData = await req.config.leadVisit.findOne({
            where:{
                visit_id: {[Op.ne]: visit_id},
                lead_id:  lead_id,
                p_visit_date,
                p_visit_time,
            }
        })
        if(visitDuplicateData) return await responseError(req, res, "lead visit request already existed with this date and time") 
     
        await visitData.update(body)
        return await responseSuccess(req, res, "visit updated")

    } catch (error) {
        return await responseError(req, res, "visit updated failed")
    }
}


exports.deleteVisit = async(req, res) =>{
    try {

        let {visit_id} = req.query
        let visitData = await req.config.leadVisit.findOne({
            where:{
                visit_id
            }
        })

        if(!visitData) return await responseError(req, res, "visit does not existed") 
        await visitData.destroy()
        return await responseSuccess(req, res, "visit deleted")

    } catch (error) {
        console.log(error)
        return await responseError(req, res, "visit deletion failed")
    }
}