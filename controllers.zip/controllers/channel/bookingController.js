const {  Op } = require("sequelize");
const {responseError, responseSuccess} = require('../../helper/responce')



exports.getleadBooking = async(req, res) =>{
    try {
        let bookingData;
        let whereClause = {};
        if(req.query.f_date){
            whereClause.createdAt = {
              [Op.gte]: req.query.f_date, // Greater than or equal to current date at midnight
              [Op.lt]:  req.query.t_date// Less than current date + 1 day at midnight
          }
        }
        if(!req.query.booking_id) {
            bookingData = await req.config.leadBooking.findAll({
                where: {
                    ...whereClause,

                },
                include: [
                    {
                      model: req.config.leads,
                      as: 'BookingleadData',
                      where: {
                        assigned_lead: req.user.user_id
                      },
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },
                      required:true,
                    }, 

                    {
                        model: req.config.channelProject,
                        as: 'BookingprojectData',
                        attributes: {
                          exclude: ["createdAt", "updatedAt", "deletedAt"],
                        },
                    },

                    {
                        model: req.config.leadBrokerage,
                        as: 'BrokerageBookingList',
                        attributes: {
                          exclude: ["createdAt", "updatedAt", "deletedAt"],
                        },
                    },
                   
                  ],
                  order: [["booking_id", "DESC"]],
            })
        }else{
            bookingData = await req.config.leadBooking.findByPk(req.query.booking_id, {
                include: [
                    {
                      model: req.config.leads,
                      as: 'BookingleadData',
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },
                      required:true,
                    }, 

                    {
                        model: req.config.channelProject,
                        as: 'BookingprojectData',
                        attributes: {
                          exclude: ["createdAt", "updatedAt", "deletedAt"],
                        },
                      },
                   
                  ],
            })
        }
        
        return await responseSuccess(req, res, "Booking data", bookingData)
       
    } catch (error) {
        console.log("error", error)
        return await responseError(req, res, "bookingList fetching failed", error)
    }
}


