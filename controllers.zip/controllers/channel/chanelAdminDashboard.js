const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const {responseError, responseSuccess} = require('../../helper/responce')
const moment = require("moment");


exports.getDashboardData = async(req, res) =>{
    try { 
        const startDate = req.query.startDate;
        let endDate =  req.query.endDate
        let leads;
        let visits;
        let booking;
        let topFiveLeads;
        let topFiveBooking;
        let topFiveVisits;
        whereClause ={};
        whereTaskClause ={};
        whereLeadClause ={};

        // Calculate the difference in days
        const differenceInDays = Math.floor((new Date(req.query.endDate) - new Date(req.query.startDate)) / (1000 * 60 * 60 * 24));
        let interval = 'weekly';

        // Set the interval based on the difference in days
        if (differenceInDays > 365) {
        interval = 'yearly';
        } else if (differenceInDays > 7) {
        interval = 'monthly';
        } else {
        interval = 'weekly';
        }
        console.log(differenceInDays)

        
         if (req.query.type === 'all'){
            endDate = moment(new Date(endDate)).add(1, "d").toDate().toISOString().split('T')[0];
        }
        // if(!req.user.isDB) {
            
        //     whereLeadClause = {
        //         assigned_lead : req.user.user_id
        //     }
        // }

      
        leads = await req.config.leads.count({
            where:{
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
            },
        })

        visits = await req.config.leadVisit.count({
            where:{
                createdAt: {
                    [Op.between]: [startDate, endDate],
                }, 
                status:'Completed'
            },  
            include: [
                {
                  model: req.config.leads,
                  as: 'leadData',
                  where: {
                    ...whereLeadClause
                  },
                  attributes: ["lead_id"],
                  required:true,
                }, 
            ],
        })

        booking = await req.config.leadBooking.count({
            where:{
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
               
            },
            include: [
                {
                  model: req.config.leads,
                  as: 'BookingleadData',
                  where: {
                    ...whereLeadClause
                  },
                  attributes: {
                    exclude: ["createdAt", "updatedAt", "deletedAt"],
                  },
                  required:true,
                },                
            ],
        })


        // topFiveLeads = await req.config.leads.findAll({
        //     where: {...whereLeadClause},
        //    order: [
        //     ['lead_id', 'DESC'],],
        //     limit: 5
        // })

        // topFiveBooking = await req.config.leadBooking.findAll({
        //     include: [
        //         {
        //           model: req.config.leads,
        //           as: 'BookingleadData',
        //           where: {
        //             ...whereLeadClause
        //           },
        //           attributes: {
        //             exclude: ["createdAt", "updatedAt", "deletedAt"],
        //           },
        //           required:true,
        //         },                
        //     ],
        //    order: [
        //     ['booking_id', 'DESC'],],
        //     limit: 5
        // })

        // topFiveVisits = await req.config.leadVisit.findAll({
        //     include: [
        //         {
        //           model: req.config.leads,
        //           as: 'leadData',
        //           where: {
        //             ...whereLeadClause
        //           },
        //           attributes: ["lead_id", 'lead_name'],
        //           required:true,
        //         }, 
        //     ],
        //    order: [
        //     ['visit_id', 'DESC'],],
        //     limit: 5
        // })

        let query = rangewise(interval, startDate, endDate, req)
        let EnrolVsAcceptquery = rangewiseEnrolVsAccept(interval, startDate, endDate, req)
        let rangewiseRequestedVsCompleteQuery = rangewiseRequestedVsComplete(interval, startDate, endDate, req)
        let rangewiseBrokergaeVsBookingQuery = rangewiseBookingvsBrokerage(interval, startDate, endDate, req)
        let rangewiseVisitVsBookingsQuery = rangewiseVisitVsBooking(interval, startDate, endDate, req)
        let topFiveLeadsQuery = topFiveQuery('leads', startDate, endDate, req)
        let topFiveVisitQuery = topFiveQuery('visit', startDate, endDate, req)
        let topFiveBookingQuery  = topFiveQuery('booking', startDate, endDate, req)

        topFiveLeads  = await req.config.sequelize.query(topFiveLeadsQuery, {
            type: QueryTypes.SELECT,
        })
        topFiveVisits = await req.config.sequelize.query(topFiveVisitQuery, {
            type: QueryTypes.SELECT,
        })
        topFiveBooking = await req.config.sequelize.query(topFiveBookingQuery, {
            type: QueryTypes.SELECT,
        })
        let barchart = await req.config.sequelize.query(query, {
            type: QueryTypes.SELECT,
        })
        let EnrolVsAcceptChart = await req.config.sequelize.query(EnrolVsAcceptquery, {
                    type: QueryTypes.SELECT,
            })

        let RequestedVsCompleteChart = await req.config.sequelize.query(rangewiseRequestedVsCompleteQuery, {
            type: QueryTypes.SELECT,
        }) 
        
        let rangewiseBrokergaeVsBookingChart = await req.config.sequelize.query(rangewiseBrokergaeVsBookingQuery, {
            type: QueryTypes.SELECT,
        })

        let rangewiseVisitVsBookingsCharts = await req.config.sequelize.query(rangewiseVisitVsBookingsQuery, {
            type: QueryTypes.SELECT,
        })
        
   

        const data = 
        await req.config.leads.findAll({
            include: [{
              model: req.config.leadBooking,
              as: 'BookingLeadList',
              required: true // This ensures that only leads with bookings are returned
            }],
            attributes: [
              'lead_id', 'createdAt',
              [Sequelize.literal('TIMESTAMPDIFF(HOUR, `db_lead`.`createdAt`, `BookingLeadList`.`createdAt`)'), 'time_difference_hours']
            ]
          })

          const timeDifferences = data.map(row => row.dataValues.time_difference_hours);
        // Calculate the total of time_difference_hours
        const totalHours = timeDifferences.reduce((sum, hours) => sum + hours, 0);

        // Calculate the average
        const averageHours = totalHours / timeDifferences.length;
      
       
        // let piechart = await req.config.sequelize.query(`SELECT dbl.status_name as 'name', COUNT(ld.lead_status_id) AS 'value' FROM db_lead_statuses AS dbl LEFT JOIN db_leads AS ld ON dbl.lead_status_id = ld.lead_status_id WHERE ld.deletedAt IS NULL AND ld.createdAt BETWEEN '${startDate}' AND '${endDate}' GROUP BY dbl.lead_status_id, dbl.status_name;`, {
        //     type: QueryTypes.SELECT,
        // })
        let dashboard = {
            leads,
            visits,
            booking,
            averageHours,
            topFiveLeads,
            topFiveBooking, 
            topFiveVisits,
            barchart,
            EnrolVsAcceptChart,
            RequestedVsCompleteChart,
            rangewiseBrokergaeVsBookingChart,
            rangewiseVisitVsBookingsCharts
        }
        return await responseSuccess(req, res, "dashborad Count", dashboard)

       
    } catch (error) {
        console.log(error)
        return await responseError(req, res, "something went wrong")
    }
}



const rangewise  = (type, startDate, endDate, req)=>{
   
    switch (type) {
        case "weekly":
        
            return `SELECT
            DATE(date) as 'date',
            COUNT(leadId) AS 'lead',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.lead_id AS leadId,
                NULL AS bookingId
            FROM
                db_leads AS ld
            WHERE ${!req.user.isDB && req.user.role_id != 3 ? 'ld.assigned_lead = '+ req.user.user_id +' and ' : ''}
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS leadId,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
                INNER JOIN db_leads on bd.lead_id = db_leads.lead_id ${!req.user.isDB ? 'and db_leads.assigned_lead = '+ req.user.user_id +'' : ''}
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            DATE(date)
        ORDER BY
            DATE(date);`

        case "monthly":
       

            return `SELECT
            CONCAT(YEAR(date), ' ', LPAD(DAYOFMONTH(MIN(date)), 2, '0'), '-', LPAD(DAYOFMONTH(MAX(date)), 2, '0')) AS 'date',
            COUNT(leadId) AS 'lead',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.lead_id AS leadId,
                NULL AS bookingId
            FROM
                db_leads AS ld
            WHERE ${!req.user.isDB && req.user.role_id != 3 ? 'ld.assigned_lead = '+ req.user.user_id +' and ' : ''}
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS leadId,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
                INNER JOIN db_leads on bd.lead_id = db_leads.lead_id ${!req.user.isDB ? 'and db_leads.assigned_lead = '+ req.user.user_id +'' : ''}
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            YEAR(date),
            WEEK(date)
        ORDER BY
            MIN(date);`


        case "yearly":
            return `SELECT
            YEAR(date) AS 'year',
            COUNT(leadId) AS 'lead',
            COUNT(bookingId) AS 'booking'
            FROM (
                SELECT
                    ld.createdAt AS date,
                    ld.lead_id AS leadId,
                    NULL AS bookingId
                FROM
                    db_leads AS ld
                WHERE ${!req.user.isDB && req.user.role_id != 3 ? 'ld.assigned_lead = '+ req.user.user_id +' and ' : ''}
                    ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
                
                UNION ALL
                
                SELECT
                    bd.createdAt AS date,
                    NULL AS leadId,
                    bd.booking_id AS bookingId
                FROM
                    db_lead_bookings AS bd
                INNER JOIN db_leads on bd.lead_id = db_leads.lead_id ${!req.user.isDB ? 'and db_leads.assigned_lead = '+ req.user.user_id +'' : ''}
                WHERE 
                    bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
            ) AS combinedData
        GROUP BY
            YEAR(date)
        ORDER BY
            MIN(date);
        ;` 
            
        case "all":
           
            return `SELECT
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0')) AS 'date',
            COUNT(leadId) AS 'lead',
            COUNT(bookingId) AS 'booking'
            FROM (
                SELECT
                    ld.createdAt AS date,
                    ld.lead_id AS leadId,
                    NULL AS bookingId
                FROM
                    db_leads AS ld
                WHERE ${!req.user.isDB && req.user.role_id != 3 ? 'ld.assigned_lead = '+ req.user.user_id +' and ' : ''}
                    ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
                
                UNION ALL
                
                SELECT
                    bd.createdAt AS date,
                    NULL AS leadId,
                    bd.booking_id AS bookingId
                FROM
                    db_lead_bookings AS bd
                    INNER JOIN db_leads on bd.lead_id = db_leads.lead_id ${!req.user.isDB ? 'and db_leads.assigned_lead = '+ req.user.user_id +'' : ''}
                WHERE 
                    bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
            ) AS combinedData
        GROUP BY
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0'))
        ORDER BY
            MIN(date);`
            
        default:
         
        return `SELECT
        DATE(date) as 'date',
        COUNT(leadId) AS 'lead',
        COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.lead_id AS leadId,
                NULL AS bookingId
            FROM
                db_leads AS ld
            WHERE ${!req.user.isDB && req.user.role_id != 3 ? 'ld.assigned_lead = '+ req.user.user_id +' and ' : ''}
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS leadId,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
                INNER JOIN db_leads on bd.lead_id = db_leads.lead_id ${!req.user.isDB ? 'and db_leads.assigned_lead = '+ req.user.user_id +'' : ''}
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
    GROUP BY
        DATE(date)
    ORDER BY
        DATE(date);`
    }
}

const rangewiseBookingvsBrokerage  = (type, startDate, endDate, req)=> {
   
    switch (type) {
        case "weekly":
        
            return `SELECT
            DATE(date) as 'date',
            COUNT(brokerageId) AS 'brokerage',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.brokerage_id AS brokerageId,
                NULL AS bookingId
            FROM
                db_lead_brokerages AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS brokerageId,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            DATE(date)
        ORDER BY
            DATE(date);`

        case "monthly":
       

            return `SELECT
            CONCAT(YEAR(date), ' ', LPAD(DAYOFMONTH(MIN(date)), 2, '0'), '-', LPAD(DAYOFMONTH(MAX(date)), 2, '0')) AS 'date',
            COUNT(brokerageId) AS 'brokerage',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.brokerage_id AS brokerageId,
                NULL AS bookingId
            FROM
                db_lead_brokerages AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS brokerageId,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            YEAR(date),
            WEEK(date)
        ORDER BY
            MIN(date);`


        case "yearly":
            return `SELECT
            YEAR(date) AS 'year',
            COUNT(brokerageId) AS 'brokerage',
            COUNT(bookingId) AS 'booking'
            FROM (
                SELECT
                ld.createdAt AS date,
                ld.brokerage_id AS brokerageId,
                NULL AS bookingId
            FROM
                db_lead_brokerages AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS brokerageId,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
            ) AS combinedData
        GROUP BY
            YEAR(date)
        ORDER BY
            MIN(date);
        ;` 
            
        case "all":
           
            return `SELECT
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0')) AS 'date',
            COUNT(brokerageId) AS 'brokerage',
            COUNT(bookingId) AS 'booking'
            FROM (
                SELECT
                ld.createdAt AS date,
                ld.brokerage_id AS brokerageId,
                NULL AS bookingId
            FROM
                db_lead_brokerages AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS brokerageId,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
            ) AS combinedData
        GROUP BY
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0'))
        ORDER BY
            MIN(date);`
            
        default:
         
        return `SELECT
        DATE(date) as 'date',
        COUNT(brokerageId) AS 'brokerage',
        COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
            ld.createdAt AS date,
            ld.brokerage_id AS brokerageId,
            NULL AS bookingId
        FROM
            db_lead_brokerages AS ld
        WHERE
            ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
        
        UNION ALL
        
        SELECT
            bd.createdAt AS date,
            NULL AS brokerageId,
            bd.booking_id AS bookingId
        FROM
            db_lead_bookings AS bd
        WHERE 
            bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
    GROUP BY
        DATE(date)
    ORDER BY
        DATE(date);`
    }
}

const rangewiseEnrolVsAccept  = (type, startDate, endDate, req)=>{
   
    switch (type) {
        case "weekly":
        
            return `SELECT
            CONCAT(YEAR(date), '-', WEEK(date)) AS week_range,
            SUM(enrolled) AS enrolled,
            SUM(approved) AS approved
        FROM (
            SELECT
                DATE(userApproved.createdAt) AS date,
                0 AS enrolled,
                COUNT(DISTINCT userApproved.user_id) AS approved
            FROM
                db_users AS userApproved
            WHERE
                userApproved.doc_verification = 2
                AND userApproved.role_id = 1
                AND userApproved.createdAt BETWEEN  '${startDate}' AND '${endDate}'
                AND userApproved.deletedAt IS NULL
            GROUP BY
                DATE(userApproved.createdAt)
        
            UNION ALL
        
            SELECT
                DATE(userEnrol.createdAt) AS date,
                COUNT(DISTINCT userEnrol.user_id) AS enrolled,
                0 AS approved
            FROM
                db_users AS userEnrol
            WHERE
                userEnrol.doc_verification != 2
                AND userEnrol.role_id = 1
                AND userEnrol.createdAt BETWEEN  '${startDate}' AND '${endDate}'
                AND userEnrol.deletedAt IS NULL
            GROUP BY
                DATE(userEnrol.createdAt)
        ) AS subquery
        GROUP BY
            CONCAT(YEAR(date), '-', WEEK(date));`

        case "monthly":
       

            return `SELECT
            CONCAT(YEAR(date), '-', MONTH(date)) AS month_range,
            SUM(enrolled) AS enrolled,
            SUM(approved) AS approved
        FROM (
            SELECT
                DATE(userApproved.createdAt) AS date,
                0 AS enrolled,
                COUNT(DISTINCT userApproved.user_id) AS approved
            FROM
                db_users AS userApproved
            WHERE
                userApproved.doc_verification = 2
                AND userApproved.role_id = 1
                AND userApproved.createdAt BETWEEN  '${startDate}' AND '${endDate}'
                AND userApproved.deletedAt IS NULL
            GROUP BY
                DATE(userApproved.createdAt)
        
            UNION ALL
        
            SELECT
                DATE(userEnrol.createdAt) AS date,
                COUNT(DISTINCT userEnrol.user_id) AS enrolled,
                0 AS approved
            FROM
                db_users AS userEnrol
            WHERE
                userEnrol.doc_verification != 2
                AND userEnrol.role_id = 1
                AND userEnrol.createdAt BETWEEN  '${startDate}' AND '${endDate}'
                AND userEnrol.deletedAt IS NULL
            GROUP BY
                DATE(userEnrol.createdAt)
        ) AS subquery
        GROUP BY
            CONCAT(YEAR(date), '-', MONTH(date));`


        case "yearly":
            return `SELECT
            YEAR(date) AS year_range,
            SUM(enrolled) AS enrolled,
            SUM(approved) AS approved
        FROM (
            SELECT
                DATE(userApproved.createdAt) AS date,
                0 AS enrolled,
                COUNT(DISTINCT userApproved.user_id) AS approved
            FROM
                db_users AS userApproved
            WHERE
                userApproved.doc_verification = 2
                AND userApproved.role_id = 1
                AND userApproved.createdAt BETWEEN  '${startDate}' AND '${endDate}'
                AND userApproved.deletedAt IS NULL
            GROUP BY
                DATE(userApproved.createdAt)
        
            UNION ALL
        
            SELECT
                DATE(userEnrol.createdAt) AS date,
                COUNT(DISTINCT userEnrol.user_id) AS enrolled,
                0 AS approved
            FROM
                db_users AS userEnrol
            WHERE
                userEnrol.doc_verification != 2
                AND userEnrol.role_id = 1
                AND userEnrol.createdAt BETWEEN  '${startDate}' AND '${endDate}'
                AND userEnrol.deletedAt IS NULL
            GROUP BY
                DATE(userEnrol.createdAt)
        ) AS subquery
        GROUP BY
            YEAR(date)` 
            
       
            
        default:
         
        return `SELECT
        date,
        SUM(enrolled) AS enrolled,
        SUM(approved) AS approved
    FROM (
        SELECT
            DATE(userApproved.createdAt) AS date,
            0 AS enrolled,
            COUNT(DISTINCT userApproved.user_id) AS approved
        FROM
            db_users AS userApproved
        WHERE
            userApproved.doc_verification = 2
            AND userApproved.role_id = 1
            AND userApproved.createdAt BETWEEN  '${startDate}' AND '${endDate}'
            AND userApproved.deletedAt IS NULL
        GROUP BY
            DATE(userApproved.createdAt)
    
        UNION ALL
    
        SELECT
            DATE(userEnrol.createdAt) AS date,
            COUNT(DISTINCT userEnrol.user_id) AS enrolled,
            0 AS approved
        FROM
            db_users AS userEnrol
        WHERE
            userEnrol.doc_verification != 2
            AND userEnrol.role_id = 1
            AND userEnrol.createdAt BETWEEN  '${startDate}' AND '${endDate}'
            AND userEnrol.deletedAt IS NULL
        GROUP BY
            DATE(userEnrol.createdAt)
    ) AS subquery
    GROUP BY
        date`
    }
}

const rangewiseRequestedVsComplete  = (type, startDate, endDate, req)=>{
   
    switch (type) {
        case "weekly":
        
            return `SELECT
            CONCAT(YEAR(date), '-', WEEK(date)) AS week_range,
            SUM(Requested) AS Requested,
            SUM(Completed) AS Completed
        FROM (
                SELECT
                    DATE(v1.createdAt) AS date,
                    COUNT(DISTINCT v1.visit_id) AS Requested,
                    0 AS Completed
                FROM
                    db_lead_visits AS v1
                WHERE
                    v1.status = 'Requested'
                    AND v1.createdAt BETWEEN '${startDate}' AND '${endDate}'
                    AND v1.deletedAt IS NULL
                GROUP BY
                    DATE(v1.createdAt)

                UNION ALL

                SELECT
                    DATE(v2.createdAt) AS date,
                    0 AS Requested,
                    COUNT(DISTINCT v2.visit_id) AS Completed
                FROM
                    db_lead_visits AS v2
                WHERE
                    v2.status = 'Completed'
                    AND v2.createdAt BETWEEN '${startDate}' AND '${endDate}'
                    AND v2.deletedAt IS NULL
                GROUP BY
                    DATE(v2.createdAt)
        ) AS subquery
        GROUP BY
            CONCAT(YEAR(date), '-', WEEK(date));`

        case "monthly":
       

            return `SELECT
            CONCAT(YEAR(date), '-', MONTH(date)) AS month_range,
            SUM(Requested) AS Requested,
            SUM(Completed) AS Completed
            FROM (
                SELECT
                    DATE(v1.createdAt) AS date,
                    COUNT(DISTINCT v1.visit_id) AS Requested,
                    0 AS Completed
                FROM
                    db_lead_visits AS v1
                WHERE
                    v1.status = 'Requested'
                    AND v1.createdAt BETWEEN '${startDate}' AND '${endDate}'
                    AND v1.deletedAt IS NULL
                GROUP BY
                    DATE(v1.createdAt)

                UNION ALL

                SELECT
                    DATE(v2.createdAt) AS date,
                    0 AS Requested,
                    COUNT(DISTINCT v2.visit_id) AS Completed
                FROM
                    db_lead_visits AS v2
                WHERE
                    v2.status = 'Completed'
                    AND v2.createdAt BETWEEN '${startDate}' AND '${endDate}'
                    AND v2.deletedAt IS NULL
                GROUP BY
                    DATE(v2.createdAt)
        )  AS subquery
        GROUP BY
            CONCAT(YEAR(date), '-', MONTH(date));`


        case "yearly":
            return `SELECT
            YEAR(date) AS year_range,
            SUM(Requested) AS Requested,
            SUM(Completed) AS Completed
        FROM (
            FROM (
                SELECT
                    DATE(v1.createdAt) AS date,
                    COUNT(DISTINCT v1.visit_id) AS Requested,
                    0 AS Completed
                FROM
                    db_lead_visits AS v1
                WHERE
                    v1.status = 'Requested'
                    AND v1.createdAt BETWEEN '${startDate}' AND '${endDate}'
                    AND v1.deletedAt IS NULL
                GROUP BY
                    DATE(v1.createdAt)

                UNION ALL

                SELECT
                    DATE(v2.createdAt) AS date,
                    0 AS Requested,
                    COUNT(DISTINCT v2.visit_id) AS Completed
                FROM
                    db_lead_visits AS v2
                WHERE
                    v2.status = 'Completed'
                    AND v2.createdAt BETWEEN '${startDate}' AND '${endDate}'
                    AND v2.deletedAt IS NULL
                GROUP BY
                    DATE(v2.createdAt)
        )  AS subquery
        GROUP BY
            YEAR(date)` 
            
       
            
        default:
         
        return `SELECT
        date,
        SUM(Requested) AS Requested,
        SUM(Completed) AS Completed
        FROM (
            SELECT
                DATE(v1.createdAt) AS date,
                COUNT(DISTINCT v1.visit_id) AS Requested,
                0 AS Completed
            FROM
                db_lead_visits AS v1
            WHERE
                v1.status = 'Requested'
                AND v1.createdAt BETWEEN '${startDate}' AND '${endDate}'
                AND v1.deletedAt IS NULL
            GROUP BY
                DATE(v1.createdAt)

            UNION ALL

            SELECT
                DATE(v2.createdAt) AS date,
                0 AS Requested,
                COUNT(DISTINCT v2.visit_id) AS Completed
            FROM
                db_lead_visits AS v2
            WHERE
                v2.status = 'Completed'
                AND v2.createdAt BETWEEN '${startDate}' AND '${endDate}'
                AND v2.deletedAt IS NULL
            GROUP BY
                DATE(v2.createdAt)
    )  AS subquery
    GROUP BY
        date`
    }
}


const rangewiseVisitVsBooking  = (type, startDate, endDate, req)=> {
   
    switch (type) {
        case "weekly":
        
            return `SELECT
            DATE(date) as 'date',
            COUNT(visitID) AS 'visit',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.visit_id AS visitID,
                NULL AS bookingId
            FROM
                db_lead_visits AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS visitID,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            DATE(date)
        ORDER BY
            DATE(date);`

        case "monthly":
       

            return `SELECT
            CONCAT(YEAR(date), ' ', LPAD(DAYOFMONTH(MIN(date)), 2, '0'), '-', LPAD(DAYOFMONTH(MAX(date)), 2, '0')) AS 'date',
            COUNT(visitID) AS 'visit',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.visit_id AS visitID,
                NULL AS bookingId
            FROM
                db_lead_visits AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS visitID,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            YEAR(date),
            WEEK(date)
        ORDER BY
            MIN(date);`


        case "yearly":
            return `SELECT
            YEAR(date) AS 'year',
            COUNT(visitID) AS 'visit',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.visit_id AS visitID,
                NULL AS bookingId
            FROM
                db_lead_visits AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS visitID,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            YEAR(date)
        ORDER BY
            MIN(date);
        ;` 
            
        case "all":
           
            return `SELECT
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0')) AS 'date',
            COUNT(visitID) AS 'visit',
            COUNT(bookingId) AS 'booking'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.visit_id AS visitID,
                NULL AS bookingId
            FROM
                db_lead_visits AS ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
            
            UNION ALL
            
            SELECT
                bd.createdAt AS date,
                NULL AS visitID,
                bd.booking_id AS bookingId
            FROM
                db_lead_bookings AS bd
            WHERE 
                bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
        ) AS combinedData
        GROUP BY
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0'))
        ORDER BY
            MIN(date);`
            
        default:
         
        return `SELECT
        DATE(date) as 'date',
        COUNT(visitID) AS 'visit',
        COUNT(bookingId) AS 'booking'
    FROM (
        SELECT
            ld.createdAt AS date,
            ld.visit_id AS visitID,
            NULL AS bookingId
        FROM
            db_lead_visits AS ld
        WHERE
            ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null 
        
        UNION ALL
        
        SELECT
            bd.createdAt AS date,
            NULL AS visitID,
            bd.booking_id AS bookingId
        FROM
            db_lead_bookings AS bd
        WHERE 
            bd.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and bd.deletedAt IS null
    ) AS combinedData
    GROUP BY
        DATE(date)
    ORDER BY
        DATE(date);`
    }
}


const topFiveQuery  = (type)=> {
   
    switch (type) {
        case "leads":
        
            return `SELECT 
            u.user_id,
            u.user,
            COUNT(l.lead_id) AS leadCount
        FROM 
            db_users u
        JOIN 
            db_leads l ON u.user_id = l.assigned_lead AND l.deletedAt IS NULL
        WHERE 
            u.deletedAt IS NULL
        GROUP BY 
            u.user_id
        ORDER BY 
            leadCount DESC
        LIMIT 5`

        case "visit":
       

            return `SELECT 
            u.user_id,
            u.user,
            COUNT(l.lead_id) AS visitCount
        FROM 
            db_users u
        JOIN 
            db_leads l ON u.user_id = l.assigned_lead AND l.deletedAt IS NULL
        JOIN
            db_lead_visits v on v.lead_id = l.lead_id and v.deletedAt IS NULL
        WHERE 
            u.deletedAt IS NULL
        GROUP BY 
            u.user_id
        ORDER BY 
            visitCount DESC
        LIMIT 5`


        case "booking":
            return `SELECT 
            u.user_id,
            u.user,
            COUNT(l.lead_id) AS bookingCount
        FROM 
            db_users u
        JOIN 
            db_leads l ON u.user_id = l.assigned_lead AND l.deletedAt IS NULL
        JOIN
            db_lead_bookings v on v.lead_id = l.lead_id and v.deletedAt IS NULL
        WHERE 
            u.deletedAt IS NULL
        GROUP BY 
            u.user_id
        ORDER BY 
            bookingCount DESC
        LIMIT 5` 
            
      
            
        default:
         
        return `SELECT 
        u.user_id,
        u.user,
        COUNT(l.lead_id) AS bookingCount
    FROM 
        db_users u
    JOIN 
        db_leads l ON u.user_id = l.assigned_lead AND l.deletedAt IS NULL
    JOIN
        db_lead_bookings v on v.lead_id = l.lead_id and v.deletedAt IS NULL
    WHERE 
        u.deletedAt IS NULL
    GROUP BY 
        u.user_id
    ORDER BY 
        bookingCount DESC
    LIMIT 5`
    }
}