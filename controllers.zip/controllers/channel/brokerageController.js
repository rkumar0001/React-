const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const {responseError, responseSuccess} = require('../../helper/responce')
const fileUpload = require("../../common/imageExport");

const zeroPad = (num, places) => String(num).padStart(places, '0')

exports.createBrokerage = async(req, res) => {
    try {
        let {booking_id, amount, date} = req.body
        let brokerageData;

        brokerageData = await req.config.leadBrokerage.findOne({
          where:{
            booking_id
          }
        })
        if(brokerageData) return await responseError(req, res, "brokerage Already Exist!")
        let leadBrokerageCount = await req.config.leadBrokerage.count({ paranoid: false}) 


        let bill_file = null;
        if (req.files && req.files.file) {
            let brokerageFile =  await fileUpload.imageExport(req, res, "brokerage");
            bill_file = brokerageFile;
        }

            // create visit
        let booking_data = await req.config.leadBooking.findByPk(booking_id)


            brokerageData = await req.config.leadBrokerage.create({booking_id, amount, date, bill_file, lead_id:booking_data.lead_id,
            brokerage_code: `${req.admin.user.charAt(0).toUpperCase()}${req.admin.user_l_name ? req.admin.user_l_name.charAt(0).toUpperCase():''}BK_${zeroPad(leadBrokerageCount+1, 5)}`,status: 'Bill sent'
        
        }) 
        return await responseSuccess(req, res, "brokerage created Succesfully", brokerageData ) 
    } catch (error) {
      console.log('error', error)
        return await responseError(req, res, "something went wrong")
    }
}



exports.getleadsBrokerage = async(req, res) =>{
    try {
        let brokerageData;
        let whereClause = {};
        if(req.query.f_date){
            whereClause.createdAt = {
              [Op.gte]: req.query.f_date, // Greater than or equal to current date at midnight
              [Op.lt]:  req.query.t_date// Less than current date + 1 day at midnight
          }
        }

        if(req.query.brokerage_id){
          brokerageData = await req.config.leadBrokerage.findByPk(req.query.brokerage_id, {
            include: [
                {
                  model: req.config.leadBooking,
                  as: 'BrokerageBookingtData',
                  attributes: {
                    exclude: ["createdAt", "updatedAt", "deletedAt"],
                  },

                  include: [
                    {
                        model: req.config.channelProject,
                        as: 'BookingprojectData',
                        attributes: {
                          exclude: ["createdAt", "updatedAt", "deletedAt"],
                        },
                    },
                  ]
                }, 

                {
                    model: req.config.leads,
                    as: 'BrokerageLeadData',
                    attributes: {
                      exclude: ["createdAt", "updatedAt", "deletedAt"],
                    },
                }, 
               
              ],
          })
        }
        else if(req.user.role_id === 2){
          // for brokergae data
          console.log("I am here")
          brokerageData = await req.config.leadBrokerage.findAll({
            where: {
                ...whereClause,
            },
            include: [
                {
                  model: req.config.leadBooking,
                  as: 'BrokerageBookingtData',
                  attributes: {
                    exclude: ["createdAt", "updatedAt", "deletedAt"],
                  },

                  include: [
                    {
                        model: req.config.channelProject,
                        as: 'BookingprojectData',
                        attributes: {
                          exclude: ["createdAt", "updatedAt", "deletedAt"],
                        },
                    },
                  ]
                }, 

                {
                    model: req.config.leads,
                    as: 'BrokerageLeadData',
                    attributes: {
                      exclude: ["createdAt", "updatedAt", "deletedAt"],
                    },
                    include: [
                      {
                          model: req.config.users,
                          where:{
                            report_to : req.user.user_id
                          },
                          attributes: {
                            exclude: ["createdAt", "updatedAt", "deletedAt"],
                          },
                          required: true
                      },
                    ],
                    required: true
                }, 
               
              ],
              order: [["brokerage_id", "DESC"]],
        })
        }else{
         
            brokerageData = await req.config.leadBrokerage.findAll({
                where: {
                    ...whereClause,
                },
                include: [
                    {
                      model: req.config.leadBooking,
                      as: 'BrokerageBookingtData',
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },

                      include: [
                        {
                            model: req.config.channelProject,
                            as: 'BookingprojectData',
                            attributes: {
                              exclude: ["createdAt", "updatedAt", "deletedAt"],
                            },
                        },
                      ]
                    }, 

                    {
                        model: req.config.leads,
                        as: 'BrokerageLeadData',
                        where: {
                          assigned_by: req.user.user_id
                        },
                        attributes: {
                          exclude: ["createdAt", "updatedAt", "deletedAt"],
                        },
                        required:true,
                    }, 
                   
                  ],
                  order: [["brokerage_id", "DESC"]],
            })
        }
        
        


       
        
        return await responseSuccess(req, res, "brokerageData list", brokerageData)
       
    } catch (error) {
        console.log("error", error)
        return await responseError(req, res, "brokerage fetching failed", error)
    }
}


exports.editleadsBrokerage = async(req, res) =>{
    try {

        let body = req.body

        let brokerageData = await req.config.leadBrokerage.findByPk(body.brokerage_id)
        if(!brokerageData) return await responseError(req, res, "no brokerage existed") 

        let brokerageNotData = await req.config.leadBrokerage.findOne({
            where: {
                brokerage_id: {[Op.ne]: body.brokerage_id},
                booking_id: body.booking_id
            }
        })
        if(!brokerageNotData) return await responseError(req, res, "booking already exist with another brokerage") 

        if (req.files && req.files.file) {
            req.body._imageName = brokerageData.bill_file || 0
            let client_image_4 =  await fileUpload.imageExport(req, res, "brokerage");
            body.bill_file = client_image_4;
          }
     
        await brokerageData.update(body)
        return await responseSuccess(req, res, "brokerage updated")

    } catch (error) {
        console.log(error)
        return await responseError(req, res, "brokerage updated failed")
    }
}




