const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const {responseError, responseSuccess} = require('../../helper/responce')
const axios = require('axios');


const zeroPad = (num, places) => String(num).padStart(places, '0');

exports.storeChannelLead = async (req, res) => {
    try {
      // Destructuring request body
      let { lead_name, email_id, p_contact_no, address, pincode, p_visit_date, p_visit_time, project_id, project_name } = req.body;
      let leadData;
  
      // Check for duplicate lead based on email, contact number, visit date, and visit time
      leadData = await req.config.leads.findOne({
        where: {
          email_id,
          p_contact_no,
          p_visit_date,
          p_visit_time
        }
      });
  
      // If duplicate lead found, return an error response
      if (leadData) {
        return await responseError(req, res, "Lead already exists with this date and time");
      }
  
      // Count the total number of leads (including soft-deleted ones)
      let leadcount = await req.config.leads.count({ paranoid: false });
  
      // Prepare lead data for insertion
      let body = {
        lead_name,
        email_id,
        p_contact_no,
        address,
        pincode,
        p_visit_date,
        p_visit_time,
        assigned_by: req.user.user_id,
        assigned_lead: req.user.user_id,
        lead_owner: req.user.user_id,
        sales_project_id: project_id,
        sales_project_name: project_name,
        lead_stg_id: 1,
        lead_code: `${req.admin.user.charAt(0).toUpperCase()}${req.admin.user_l_name ? req.admin.user_l_name.charAt(0).toUpperCase() : ''}L_${zeroPad(leadcount + 1, 5)}`
      };


      const fetchAccessToken = async (retries = 3) => {
        const fetch = (await import('node-fetch')).default;
        const url = "https://test.salesforce.com/services/oauth2/token";
        const params = new URLSearchParams({
          username: "admin@saleofast.com.postsales",
          password: "Kloudrac@123vYX98EkG31lg5Px0ZnL7htFFa",
          grant_type: "password",
          client_id: "3MVG9Po2PmyYruunGgi2prNyVV6tkMw2sEKnTxnl__qXGx8UtKhsi7cKL8WnfdaCyy9d7q5yB5slQkjvL3jvS",
          client_secret: "11B5983495743D8DBA34CC3B5D12FAD8F0F11106ED19A7E00A01403F7942195E"
        });
  
        const requestOptions = {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: params.toString(),
          redirect: "follow"
        };
  
        for (let attempt = 1; attempt <= retries; attempt++) {
          try {
            const response = await fetch(url, requestOptions);
            if (!response.ok) {
              throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return await response.json(); // Assuming the response is JSON
          } catch (error) {
            if (attempt < retries) {
              console.log(`Retry attempt ${attempt} failed. Retrying...`);
              await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
            } else {
              throw error;
            }
          }
        }
      };
  
      const tokenResponse = await fetchAccessToken();
        // Prepare lead data for Salesforce

        if(tokenResponse && tokenResponse.access_token ){
          
        let salesforceData = JSON.stringify({
          "Clead_Full_Name__c": lead_name,
          "Cell_Phone__c": p_contact_no,
          "Email__c": email_id,
          "Pin_Code__c": pincode,
          "Location__c": address,
          "Requirement_Type__c": "Residential",
          "Country_pklst__c": "India",
          "Registration_Type_pklst__c": "Phone Call",
          "Selected_Project_rltn__c": project_id
        });

        // Configure Salesforce lead creation request
        let leadConfig = {
          method: 'post',
          maxBodyLength: Infinity,
          url: 'https://saleofast--postsales.sandbox.my.salesforce.com/services/data/v56.0/sobjects/Clead__c',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${tokenResponse.access_token}`,
          },
          data: salesforceData
        };

        // Create lead in Salesforce
        axios.request(leadConfig)
          .then((response) => {
            body.sales_lead_id = response.data.id;

            // Insert the lead data into the database
              req.config.leads.create(body).then(async (leadData) => {
              return await responseSuccess(req, res, "Lead created successfully", leadData);
            }).catch((error) => {
              console.error("Error creating lead:", error);
              return  responseError(req, res, "Something went wrong while creating the lead");
            });
          })
        }else{
          return await responseError(req, res, "token genration failed", tokenResponse);
        }
  
      // Request Salesforce token
   
  
    } catch (error) {
      console.error("Error:", error);
      return await responseError(req, res, "Something went wrong");
    }
  };



exports.getleads = async(req, res) =>{
    try {
        let leadData;
        let whereClause = {};
        if(req.query.f_date){
            whereClause.createdAt = {
              [Op.gte]: req.query.f_date, // Greater than or equal to current date at midnight
              [Op.lt]:  req.query.t_date// Less than current date + 1 day at midnight
          }
        }
        if(!req.query.lead_id) {
            leadData = await req.config.leads.findAll({
                where: {
                    ...whereClause,
                    assigned_lead: req.user.user_id
                },
                include: [
                    {
                      model: req.config.channelProject,
                      as: 'projectData',
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },
                    },

                    {
                      model: req.config.leadStages,
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },
                    },

                    {
                        model: req.config.leadVisit,
                        as: 'visitList',
                        attributes: {
                          exclude: ["updatedAt", "deletedAt"],
                        },
                        order: [["visit_id", "DESC"]],
                        limit: 1
                    },

                    
                   
                  ],
                  order: [["lead_id", "DESC"]],
            })
        }else{  
            leadData = await req.config.leads.findByPk(req.query.lead_id, {
                include: [
                    {
                      model: req.config.channelProject,
                      as: 'projectData',
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },
                    },

                    {
                      model: req.config.leadStages,
                      attributes: {
                        exclude: ["createdAt", "updatedAt", "deletedAt"],
                      },
                    },

                   
                  ]
            })
        }
        
        return await responseSuccess(req, res, "leadList list", leadData)
       
    } catch (error) {
        console.log("error", error)
        return await responseError(req, res, "leadList fetching failed")
    }
}




exports.editleads = async(req, res) =>{
    try {

        let {lead_id, email_id, p_contact_no, p_visit_date, p_visit_time,} = req.body
        let body = req.body

        let leadData = await req.config.leads.findByPk(lead_id)
        if(!leadData) return await responseError(req, res, "no lead existed") 

        let leadDuplicateData = await req.config.leads.findOne({
            where:{
                lead_id: {[Op.ne]: lead_id},
                email_id,
                p_contact_no,
            }
        })
        if(leadDuplicateData) return await responseError(req, res, "lead name already existed with this email id") 
     
        await leadData.update(body)
        return await responseSuccess(req, res, "lead updated")

    } catch (error) {
        return await responseError(req, res, "lead updated failed")
    }
}


exports.deleteleads = async(req, res) =>{
    try {

        let {lead_id} = req.body
        let leadData = await req.config.leads.findOne({
            where:{
                lead_id
            }
        })

        if(!leadData) return await responseError(req, res, "lead name does not existed") 
        await leadData.destroy()
        return await responseSuccess(req, res, "lead deleted")

    } catch (error) {
        console.log(error)
        return await responseError(req, res, "lead deletion failed")
    }
}


exports.getSalesForceToken = async(req, res) =>{
    try {

            let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://test.salesforce.com/services/oauth2/token?username=admin%40saleofast.com.postsales&password=Kloudrac%40123vYX98EkG31lg5Px0ZnL7htFFa&grant_type=password&client_id=3MVG9Po2PmyYruunGgi2prNyVV6tkMw2sEKnTxnl__qXGx8UtKhsi7cKL8WnfdaCyy9d7q5yB5slQkjvL3jvS&client_secret=11B5983495743D8DBA34CC3B5D12FAD8F0F11106ED19A7E00A01403F7942195E',
            headers: { 
                'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiZGJfbmFtZSI6Ik1VTFRJX1VTRVI5ODk0MTA5NiIsInVzZXJfY29kZSI6IlVTRVI5ODk0MTA5NiIsImlhdCI6MTcxNTg0MjIzNiwiZXhwIjoxNzE1ODcxMDM2fQ.pZ3QE4XFrDT5ZCBkzP2_4Zzw09TIHJZoIJhO4tdRw5Y', 
                'Cookie': 'BrowserId=uISrwxHlEe-g1NsuvW73ow; CookieConsentPolicy=0:0; LSKey-c$CookieConsentPolicy=0:0'
            }
            };

            axios.request(config)
            .then((response) => {
            console.log(JSON.stringify(response.data));
            return responseSuccess(req, res, "response.data", response.data)
            })
            .catch((error) => {
            console.log(error);
            return responseError(req, res, "lead updated failed")
            });

    } catch (error) {
        return await responseError(req, res, "lead updated failed")
    }
}

exports.fetchOrderNO = async(req, res) =>{
    try {
            const { queryStr} = req.body
            if(!queryStr) return await responseError(req, res, "empty string")
            var myWord = 'number';
            let result = new RegExp('\\b' + myWord + '\\b').test(queryStr);
            if(result){
                let order = queryStr.toString().split('number: ')[1].split('Date')[0]
                return responseSuccess(req, res, "response.data", order.slice(0,order.length-1))
            }else{
                return await responseError(req, res, "Order id doesnt exist ")
            }
             // false

        
           
            
    } catch (error) {
        console.log(error, "error")
        return await responseError(req, res, "Order got error")
    }
}

// exports.getProjectList = async(req, res) =>{
//     try {
//         let accesstoken = ''
//             // let config = {
//             // method: 'post',
//             // url: `https://test.salesforce.com/services/oauth2/token?username=${process.env.USERNAME}&password=${process.env.SALESFORCE_PWD}&grant_type=${process.env.GRANTTYPE}&client_id=${process.env.SALESFORCE_CLIENT_ID}&client_secret=${process.env.SALESFORCE_CLIENT_PWD}`,
//             // };

//             // axios.request(config)
//             // .then((response) => {
//             //     accesstoken = response.data.access_token
//             //     let configProject = {
//             //         method: 'get',
//             //         maxBodyLength: Infinity,
//             //         url: 'https://saleofast--postsales.sandbox.my.salesforce.com/services/data/v56.0/query?q=SELECT+Id,Project_Name__c+FROM+CProject__c',
//             //         headers: { 
//             //           'Authorization': `Bearer ${accesstoken}`, 
//             //           'Cookie': 'BrowserId=uISrwxHlEe-g1NsuvW73ow; CookieConsentPolicy=0:1; LSKey-c$CookieConsentPolicy=0:1'
//             //         }
//             //       };
                  
//             //       axios.request(configProject)
//             //       .then((response) => {
//             //         console.log(JSON.stringify(response.data));
//             //         return  responseSuccess(req, res, "project list", response.data)
//             //       })
//             //       .catch((error) => {
//             //         return responseError(req, res, "project list fetch failed")
//             //       });
//             // })
//             // .catch((error) => {
//             // console.log(error);
//             // return responseError(req, res, "project list fetch failed")
//             // });

//             const myHeaders = new Headers();


//     } catch (error) {
//       console.log("error",error)
//         return await responseError(req, res, "project list fetch failed")
//     }
// }

exports.getProjectList = async (req, res) => {
  try {
    const fetchAccessToken = async (retries = 3) => {
      const fetch = (await import('node-fetch')).default;
      const url = "https://test.salesforce.com/services/oauth2/token";
      const params = new URLSearchParams({
        username: "admin@saleofast.com.postsales",
        password: "Kloudrac@123vYX98EkG31lg5Px0ZnL7htFFa",
        grant_type: "password",
        client_id: "3MVG9Po2PmyYruunGgi2prNyVV6tkMw2sEKnTxnl__qXGx8UtKhsi7cKL8WnfdaCyy9d7q5yB5slQkjvL3jvS",
        client_secret: "11B5983495743D8DBA34CC3B5D12FAD8F0F11106ED19A7E00A01403F7942195E"
      });

      const requestOptions = {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params.toString(),
        redirect: "follow"
      };

      for (let attempt = 1; attempt <= retries; attempt++) {
        try {
          const response = await fetch(url, requestOptions);
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return await response.json(); // Assuming the response is JSON
        } catch (error) {
          if (attempt < retries) {
            console.log(`Retry attempt ${attempt} failed. Retrying...`);
            await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
          } else {
            throw error;
          }
        }
      }
    };

    const tokenResponse = await fetchAccessToken();

    const fetchProjectList = async (accessToken, retries = 3) => {
      const fetch = (await import('node-fetch')).default;
      const url = 'https://saleofast--postsales.sandbox.my.salesforce.com/services/data/v56.0/query?q=SELECT+Id,Project_Name__c+FROM+CProject__c';
      const requestOptions = {
        method: "GET",
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        redirect: "follow"
      };

      for (let attempt = 1; attempt <= retries; attempt++) {
        try {
          const response = await fetch(url, requestOptions);
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return await response.json();
        } catch (error) {
          if (attempt < retries) {
            console.log(`Retry attempt ${attempt} failed. Retrying...`);
            await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // Exponential backoff
          } else {
            throw error;
          }
        }
      }
    };

  
    const accessToken = tokenResponse.access_token;

    const projectList = await fetchProjectList(accessToken);
    return responseSuccess(req, res, "project list", projectList);

  } catch (error) {
    console.error("Error fetching project list:", error);
    return await responseError(req, res, "project list fetch failed");
  }
};
