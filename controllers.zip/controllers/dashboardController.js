const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const {responseError, responseSuccess} = require('../helper/responce')
const moment = require("moment");

exports.getContact = async(req, res) =>{
    try { 
        const startDate = req.query.startDate;
        let endDate =  req.query.endDate
        let leads;
        let openLead
        let accounts
        let whereClause ={};
        let whereTaskClause ={};
        let whereOpprAmount ={};
        
         if (req.query.type === 'all'){
            endDate = moment(new Date(endDate)).add(1, "d").toDate().toISOString().split('T')[0];
        }
    
        if(!req.user.isDB){
            whereClause = {
                opp_owner: req.user.user_id
            }
            whereTaskClause = {
                assigned_to : req.user.user_id
            }

            whereOpprAmount = {
                assigned_to : req.user.user_id
            }
        }

      
        leads = await req.config.leads.count({
                where:{
                    createdAt: {
                        [Op.between]: [startDate, endDate],
                    },
                },
        })

        openLead = await req.config.leads.count({
            where:{
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
                lead_status_id: 1
            },
        })

        accounts = await req.config.accounts.count({
            where:{
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
            },
        })

        task = await req.config.tasks.count({
            where:{
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
                task_status_id: 1
            },
        })

        opportunities = await req.config.opportunities.count({
            where:{
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
            },
        })

       
        let opportunitiesCostResult = await req.config.opportunities.findAll({
            where: {
                ...whereOpprAmount,
                opportunity_stg_id: {
                    [Op.ne]: 4
                },
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
            },
            attributes: [[Sequelize.fn("SUM", Sequelize.col("amount")), "totalAmount"]],
            raw: true
        });
        
        let quotationCostResult = await req.config.quatMasters.findAll({
            where: {
                ...whereOpprAmount,
                quat_status : 5,
                createdAt: {
                    [Op.between]: [startDate, endDate],
                },
            },
            attributes: [[Sequelize.fn("SUM", Sequelize.col("grand_total")), "totalGrandTotal"]],
            raw: true
        });
   

        topOpportunities = await req.config.opportunities.findAll({
            where: whereClause,
           order: [
            ['amount', 'DESC'],],
            limit: 5
        })

        latestTasks = await req.config.tasks.findAll({
            where: whereTaskClause,
            attributes: [
                'task_id',
                'task_name',
                'task_status_id',
                'task_priority_id',
                'link_with_opportunity',
                'due_date',
                "assigned_to",
                "created_by",
                "description",
                "createdAt",
                "updatedAt",
                "deletedAt",
                [req.config.sequelize.literal(`DATEDIFF(due_date, NOW())`), 'days_left']
              ],            
         order: [
            ['due_date', 'DESC'],
          ],
          limit: 5
        })

        let query = rangewise(req.query.type, startDate, endDate)

        let barchart = await req.config.sequelize.query(query, {
            type: QueryTypes.SELECT,
        })

       
        let piechart = await req.config.sequelize.query(`SELECT dbl.status_name as 'name', COUNT(ld.lead_status_id) AS 'value' FROM db_lead_statuses AS dbl LEFT JOIN db_leads AS ld ON dbl.lead_status_id = ld.lead_status_id WHERE ld.deletedAt IS NULL AND ld.createdAt BETWEEN '${startDate}' AND '${endDate}' GROUP BY dbl.lead_status_id, dbl.status_name;`, {
            type: QueryTypes.SELECT,
        })

        let opportunitiesCost = opportunitiesCostResult[0].totalAmount || 0;
        let quotationCost = quotationCostResult[0].totalGrandTotal || 0;

        let dashboard = {
            leads,
            openLead,
            accounts,
            task,
            latestTasks,
            opportunities,
            topOpportunities,
            opportunitiesCost,
            quotationCost,
            barchart,
            piechart
        } 
        return await responseSuccess(req, res, "lead Count", dashboard)

       
    } catch (error) {
        console.log(error)
        return await responseError(req, res, "something went wrong")
    }
}

const rangewise  = (type, startDate, endDate)=>{
   
    switch (type) {
        case "weekly":
             
            return `SELECT
            DATE(date) as 'date',
            COUNT(leadId) AS 'lead',
            COUNT(oppId) AS 'opportunity'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.lead_id AS leadId,
                NULL AS oppId
            FROM
                db_leads ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null
            
            UNION ALL
            
            SELECT
                od.createdAt AS date,
                NULL AS leadId,
                od.opp_id AS oppId
            FROM
                db_opportunities od
            WHERE
                od.createdAt BETWEEN  '${startDate}' AND '${endDate}'   and od.deletedAt IS null
        ) AS combinedData
        GROUP BY
            DATE(date)
        ORDER BY
            DATE(date);`

        case "monthly":
             
            return `SELECT
            CONCAT(YEAR(date), ' ', LPAD(DAYOFMONTH(MIN(date)), 2, '0'), '-', LPAD(DAYOFMONTH(MAX(date)), 2, '0')) AS 'date',
            COUNT(leadId) AS 'lead',
            COUNT(oppId) AS 'opportunity'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.lead_id AS leadId,
                NULL AS oppId
            FROM
                db_leads ld
            WHERE
                ld.createdAt BETWEEN '${startDate}' AND '${endDate}'  and ld.deletedAt IS null
            
            UNION ALL
            
            SELECT
                od.createdAt AS date,
                NULL AS leadId,
                od.opp_id AS oppId
            FROM
                db_opportunities od
            WHERE
                od.createdAt BETWEEN '${startDate}' AND '${endDate}'  and od.deletedAt IS null
        ) AS combinedData
        GROUP BY
            YEAR(date),
            WEEK(date)
        ORDER BY
            MIN(date);`

        case "all":
           
            return `SELECT
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0')) AS 'date',
            COUNT(leadId) AS 'lead',
            COUNT(oppId) AS 'opportunity'
        FROM (
            SELECT
                ld.createdAt AS date,
                ld.lead_id AS leadId,
                NULL AS oppId
            FROM
                db_leads ld
            WHERE
                ld.createdAt BETWEEN  '2023-01-01' AND '${endDate}' and ld.deletedAt IS null
            
            UNION ALL
            
            SELECT
                od.createdAt AS date,
                NULL AS leadId,
                od.opp_id AS oppId
            FROM
                db_opportunities od
            WHERE
                od.createdAt BETWEEN '2023-01-01' AND '${endDate}' and od.deletedAt IS null
        ) AS combinedData
        GROUP BY
            CONCAT(YEAR(date), '-', LPAD(MONTH(date), 2, '0'))
        ORDER BY
            MIN(date);`
            
        default:
         
            return `SELECT
        DATE(date),
        COUNT(leadId) AS leadCount,
        COUNT(oppId) AS opportunity
    FROM (
        SELECT
            ld.createdAt AS date,
            ld.lead_id AS leadId,
            NULL AS oppId
        FROM
            db_leads ld
        WHERE
            ld.createdAt BETWEEN '${startDate}' AND '${endDate}' and ld.deletedAt IS null
        
        UNION ALL
        
        SELECT
            od.createdAt AS date,
            NULL AS leadId,
            od.opp_id AS oppId
        FROM
            db_opportunities od
        WHERE
            od.createdAt BETWEEN '${startDate}' AND '${endDate}'  and od.deletedAt IS null
    ) AS combinedData
    GROUP BY
        DATE(date)
    ORDER BY
        DATE(date);`
    }
}