const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const { responseSuccess, responseError } = require("../helper/responce");
const sendEmail = require("../common/mailer")
const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');


exports.storeField = async(req, res) =>{
 
    try {
            const FiledBody = req.body
            let FieldData = await req.config.Field.bulkCreate(FiledBody, { updateOnDuplicate: ["field_id","field_lable","navigate_type","field_name", "field_order", "option", "input_value", "input_type", "field_type", "field_size"] })
            
            await responseSuccess(req, res, "lead extra data submitted successfully", FieldData)
    } catch (error) {
        console.log(error)
       
        await responseError(req, res, "Something went wrong")
    }
}


exports.getField = async(req, res) =>{
    try {
            let FieldData
            const id = req.query.id
            if(id){
                FieldData = await req.config.Field.findByPk(id)
            }else{
                FieldData = await req.config.Field.findAll({
                    where: {
                        navigate_type: req.query.nav_type
                    },
                    order: [['field_order','ASC']]
                })
            }
            
            await responseSuccess(req, res, "Field Data", FieldData)
    } catch (error) {
        console.log(error)
        await responseError(req, res, "Something went wrong")
    }
}

exports.deleteField = async(req, res) =>{
    try {
            const FieldData = await req.config.Field.findByPk(req.query.id)
            if (!FieldData) responseError(req, res, "field not found")
            await FieldData.destroy()
            await responseSuccess(req, res, "Field Data deleted")
    } catch (error) {
        console.log(error)
        await responseError(req, res, "Something went wrong")
    }
}