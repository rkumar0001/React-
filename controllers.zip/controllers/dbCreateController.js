const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const {PREFIX} = require('../config/constant')
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../model");
const { first } = require("../connectionResolver/firstConnection");
const fileUpload = require("../common/imageExport");
const crypto = require("crypto");
const sendEmail = require("../common/mailer");
const fs = require("fs");
const path = require("path");
const xlsx = require("xlsx");
const dbConfig = require("../config/db.config.js");
const { middle } = require("../connectionResolver/middleConnection.js");

const Client = db.clients;
const Super = db.supers;

const randomCodeGenrator = (name) => {
  var result = "";
  result = Math.floor(10000000 + Math.random() * 90000000);
  var code = name + result;
  return code;
};

exports.admin = async (req, res) => {
  try {
    let { email, password } = req.body;
    let userData = await Super.findOne({
      where: {
        email: email,
      },
    });
    if (!userData)
      return res.status(400).json({ status: 400, data: "email not found" });
    const isSame = await bcrypt.compare(password, userData.password);
    if (userData && isSame) {
      let token = jwt.sign({ id: userData.superCode }, process.env.CLIENT_SECRET, {
        expiresIn: process.env.expiresIn,
      });
      return res.status(200).json({ userData, token });
    } else {
      return res.status(400).json({ message: "Auth Failed" });
    }
  } catch (error) {
    console.log(error);
    return res.status(400).json({ message: "sonething went wrong" });
  }
};


exports.getSuperAdminDetail = async (req, res) => {
  try {
    let superAdminData = await Super.findByPk(1, {
      attributes: {
        exclude: ["password"],
      },
    });
    if (!superAdminData)
      return res
        .status(404)
        .json({ status: 404, message: "super admin not found" });
    return res
      .status(200)
      .json({ status: 200, message: "super admin data", data: superAdminData });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.editAdminProfile = async (req, res) => {
  try {
    let body = req.body;
    let userData = await Super.findByPk(body.user_id);
    if (!userData)
      return res
        .status(404)
        .json({ status: 404, message: "something went wrong" });
    if (body.password) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(body.password, salt);
      body.password = hashedPassword;
    }
    await userData.update(body);
    return res
      .status(200)
      .json({ status: 200, message: "profile updated successfully" });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "sonething went wrong" });
  }
};

exports.editAdminProfileIMG = async (req, res) => {
  try {
    let { path, user_id } = req.body;
    const data = await fileUpload.imageExport(req, res, path);
    if (!data.message) {
      let updatedIcon = await Super.update(
        { profile_img: data },
        {
          where: {
            user_id: user_id,
          },
        }
      );
      return res
        .status(200)
        .json({
          status: 200,
          message: "profile image updated",
          data: updatedIcon,
        });
    } else {
      return res
        .status(400)
        .json({ status: 400, message: "image cannot updated" });
    }
  } catch (error) {
    console.log(error, "error on send");
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.db_creater = async (req, res) => {
  const process = await db.sequelize.transaction();
  try {
    let {
      user,
      email,
      contact_number,
      subscription_start_date,
      subscription_end_date,
      country_id,
      state_id,
      district_id,
      city_id,
      domain,
      no_of_months,
      no_of_license,
      no_of_channel_license,
      no_of_dms_license,
      no_of_sales_license,
      sidebar_color,
      button_color,
      text_color,
      gst,
      pan,
      address,
      pincode,
      isCRM,
      isDMS,
      isSALES,
      isCHANNEL,
      client_url,
      host_name
    } = req.body;
    let userCode = randomCodeGenrator("USER");
    let userPassword = await bcrypt.hash(userCode, 10);

    // creating client data for super admin DB oin clinet table
    let data = {
      user,
      user_code: userCode,
      email,
      contact_number: contact_number,
      doc_verification: 2,
      password: userPassword,
      db_name: `${PREFIX}${userCode}`,
      subscription_start_date,
      subscription_end_date,
      report_to: null,
      domain: domain && domain != undefined && domain != null ? domain : null,
      no_of_months,
      no_of_license,
      client_url,
      no_of_channel_license : no_of_channel_license || 0  ,
      no_of_dms_license : no_of_dms_license || 0,
      no_of_sales_license : no_of_sales_license || 0,
      sidebar_color: sidebar_color || '#405189',
      button_color: button_color || '#405189',
      text_color: text_color || '#405189',
      top_nav_color: text_color || '#405189',
      gst: gst && gst != undefined && gst != null ? gst : null,
      pan: pan && pan != undefined && pan != null ? pan : null,
      address:address && address != undefined && address != null ? address : null,
      host_name:host_name && host_name != undefined && host_name != null ? host_name : null,
    };


    if(data.client_url){
      if(data.client_url.charAt(data.client_url.length-1) === '/')
        data.client_url.splice(data.client_url.length-1)
    }

    // find wether the db name exist or not in clinet table


    let userData = await Client.findOne(
      {
        where: {
          db_name: `${PREFIX}${userCode}`,
        },
      },
      { transaction: process }
    );

    if (userData) {
      await process.cleanup();
      return res.status(400).json({ message: "DB existed" });
    } else {
      let isEmail = await Client.findOne(
        {
          where: {
            email: email,
          },
        },
        { transaction: process }
      );

      if (isEmail) {
        await process.cleanup();
        return res.status(400).json({ message: "email already existed" });
      }

      await db.sequelize.query(`CREATE DATABASE ${PREFIX}${userCode};`, {
        transaction: process,
      });

      const resetToken = crypto.randomBytes(32).toString("hex");
      data.password_reset_token = crypto
        .createHash("sha256")
        .update(resetToken)
        .digest("hex");

      const message = `Welcome to the KloudRac. We are glad you became part of us .<br/> Click this link to reset your password : <a href="http://crm.cybermatrixsolutions.com/ChangePassword?tkn=u$34${data.password_reset_token}" target="_blank"><b> Click here </b></a>:`;

      let option = {
        email: email,
        subject: "KloudRac",
        message: message,
      };
      await sendEmail(option);
      data.isDB = true;

      let logoImage = "";
      let client_image_1 = "";
      let client_image_2 = "";
      let client_image_3 = "";
      let client_image_4 = "";
      if (req.files && req.files.logo) {
        logoImage =  await fileUpload.imageExport(req, res, "logo", "logo");
        data.logo = logoImage;
      }

      if (req.files && req.files.client_image_1) {
        client_image_1 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_1");
        data.client_image_1 = client_image_1;
      }

      if (req.files && req.files.client_image_2) {
        client_image_2 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_2");
        data.client_image_2 = client_image_2;
      }

      if (req.files && req.files.client_image_3) {
        client_image_3 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_3");
        data.client_image_3 = client_image_3;
      }

      if (req.files && req.files.client_image_4) {
        client_image_4 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_4");
        data.client_image_4 = client_image_4;
      }

      let UserData = await Client.create(data, { transaction: process });
      // create platform permission

      await db.sequelize.query(
        `Call proc_client_platform(:db_name, :client_id, :isCRM, :isDMS, :isSALES, :isCHANNEL, 'sup')`,
        {
          replacements: {
            db_name: dbConfig.DB,
            client_id: UserData.user_id,
            isCRM: !isCRM || isCRM == 'undefined' || isCRM == null  ? 0 : isCRM,
            isDMS: !isDMS || isDMS == 'undefined' || isDMS == null  ? 0 : isDMS,
            isSALES: !isSALES || isSALES == 'undefined' || isSALES == null  ? 0 : isSALES,
            isCHANNEL: !isCHANNEL || isCHANNEL == 'undefined' || isCHANNEL == null  ? 0 : isCHANNEL,
          },
          type: QueryTypes.INSERT,
          transaction: process,
        }
      );

      await db.sequelize.query(`Call proClientPermission(:userID)`, {
        replacements: { userID: UserData.user_id },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      // first time sync db
      let nUserDB = await first(`${PREFIX}${userCode}`, req, res);
      await nUserDB.sequelize.close();

      await db.sequelize.query(`Call procCountry(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procRole(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procStates(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procDistricts(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procCity(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(
        `Call proc_platform(:db_name, :isCRM, :isDMS, :isSALES, :isCHANNEL)`,
        {
          replacements: {
            db_name: `${PREFIX}${userCode}`,
            isCRM: isCRM ? isCRM : 0,
            isDMS: isDMS ? isDMS : 0,
            isSALES: isSALES ? isSALES : 0,
            isCHANNEL: isCHANNEL ? isCHANNEL : 0,
          },
          type: QueryTypes.INSERT,
          transaction: process,
        }
      );
      
      const query = `INSERT INTO ${PREFIX}${userCode}.db_users (user, email, contact_number, password, db_name, isDB, user_status, user_code, role_id, password_reset_token, password_reset_expires, country_id, state_id, city_id, district_id, address, pincode, report_to, domain , no_of_months ,no_of_license, gst, nda, remarks,logo, createdAt, updatedAt , deletedAt, doc_verification) VALUES (:user, :email, :contact_number, :password, :db_name, :isDB, :user_status, :user_code, :role_id, :password_reset_token, :password_reset_expires, :country_id, :state_id, :city_id, :district_id, :address, :pincode, :report_to, :domain, :no_of_months,
            :no_of_license, :gst, :nda, :remarks,:logo, :createdAt, :updatedAt , :deletedAt, :doc_verification);`;

      await db.sequelize.query(query, {
        replacements: {
          user,
          email,
          contact_number: contact_number,
          password: userPassword,
          db_name: `${PREFIX}${userCode}`,
          isDB: true,
          user_status: true,
          user_code: userCode,
          role_id: null,
          password_reset_token: null,
          password_reset_expires: null,
          country_id:
            country_id && country_id != undefined && country_id != null
              ? country_id
              : null,
          state_id:
            state_id && state_id != undefined && state_id != null
              ? state_id
              : null,
          city_id:
            city_id && city_id != undefined && city_id != null ? city_id : null,
          district_id:
            district_id && district_id != undefined && district_id != null
              ? district_id
              : null,
          address:
            address && address != undefined && address != null ? address : null,
          pincode:
            pincode && pincode != undefined && pincode != null ? pincode : null,
          report_to: null,
          domain:
            domain && domain != undefined && domain != null ? domain : null,
          no_of_months:
            no_of_months && no_of_months != undefined && no_of_months != null
              ? no_of_months
              : null,
          no_of_license:
            no_of_license && no_of_license != undefined && no_of_license != null
              ? no_of_license
              : null,
          gst: gst && gst != undefined && gst != null ? gst : null,
          nda: 0,
          remarks: null,
          logo:logoImage,
          createdAt: new Date(),
          updatedAt: new Date(),
          deletedAt: null,
          doc_verification: 2,
        },
        transaction: process,
        type: Sequelize.QueryTypes.INSERT,
      });

      const queryData = await db.sequelize.query(
        `Select * from ${PREFIX}${userCode}.db_users where db_users.user_code = "${userCode}"`,
        {
          type: QueryTypes.SELECT,
          transaction: process,
        }
      );

      const profileQuery = `INSERT INTO ${PREFIX}${userCode}.db_user_profiles (user_id, div_id, dep_id, des_id, aadhar_no, aadhar_file, pan_no, pan_file, dl_no, dl_file, user_image_file, bank_name, account_holder_name, account_no, bank_ifsc_code, branch,  createdAt, updatedAt, deletedAt) VALUES (:user_id, :div_id, :dep_id, :des_id, :aadhar_no, :aadhar_file, :pan_no, :pan_file, :dl_no, :dl_file, :user_image_file, :bank_name, :account_holder_name, :account_no, :bank_ifsc_code, :branch ,'2023-05-01 02:21:14.000000', '2023-05-01 02:21:14.000000', NULL)`;
     
      let profileQueryData = await db.sequelize.query(profileQuery, {
        replacements: {
          user_id: queryData[0].user_id,
          div_id: null,
          dep_id: null,
          des_id: null,
          aadhar_no: null,
          aadhar_file: null,
          pan_no: pan && pan != undefined && pan != null ? pan : null,
          pan_file: null,
          dl_no: null,
          dl_file: null,
          user_image_file: null,
          bank_name: null,
          account_holder_name: null,
          account_no: null,
          bank_ifsc_code: null,
          branch: null,
          createdAt: new Date(),
          updatedAt: new Date(),
          deletedAt: null,
        },
        transaction: process,
        type: Sequelize.QueryTypes.INSERT,
      });

      await db.sequelize.query(`Call procMenu(:db_name, "create_menu")`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procLeadStatus(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procOpprType(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procLeadSources(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });
      await db.sequelize.query(`Call procLeadRate(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });
      await db.sequelize.query(`Call proc_lead_stage(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });
      await db.sequelize.query(`Call procLeadIndustry(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procTaskStatus(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procAccType(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      await db.sequelize.query(`Call procTax(:db_name)`, {
        replacements: { db_name: `${PREFIX}${userCode}` },
        type: QueryTypes.INSERT,
        transaction: process,
      });

      process.commit();
      return res.status(200).json({ message: "DB created", data: UserData });
    }


  } catch (error) {
    process.rollback();
    console.log(error);
    return res.status(400).json({ message: error });
  }
};

exports.downloadExcelData = async (req, res) => {
  try {
    let ClientData = await Client.findAll({
      where: {
        isDB: true,
      },
      attributes: [
        ["user", "User"],
        ["email", "Email"],
        ["contact_number", "Contact no"],
        ["db_name", "Database name"],
        ["user_code", "User Code"],
        ["subscription_start_date", "Subscription start date"],
        ["subscription_end_date", "Subscription end date"],
        ["no_of_months", "No of Months"],
        ["domain", "Domain"],
        ["no_of_license", "No of License"],
        ["gst", "GST"],
        ["pan", "Pan no"],
        ["address", "Address"],
      ],
    });
    let excelClientData = ClientData?.map((item) => item.dataValues);
    const workbook = xlsx.utils.book_new();
    const worksheet = xlsx.utils.json_to_sheet(excelClientData);
    // Add the worksheet to the workbook
    xlsx.utils.book_append_sheet(workbook, worksheet, "Sheet1");

    // Generate a temporary file path to save the Excel workbook
    const tempFilePath = path.join(
      __dirname,
      `../uploads/temp`,
      "temp.xlsx"
    );

    // Write the workbook to a file
    xlsx.writeFile(workbook, tempFilePath);

    // Set the response headers
    res.setHeader("Content-Type", "application/vnd.ms-excel");
    res.setHeader("Content-Disposition", "attachment; filename=example.xlsx");

    // Stream the file to the response
    const stream = fs.createReadStream(tempFilePath);
    stream.pipe(res);

    // Delete the temporary file after sending the response
    stream.on("end", () => {
      fs.unlinkSync(tempFilePath);
    });
    return;
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "Something went wrong" });
  }
};

exports.db_login = async (req, res) => {
  try {
    let { email, password } = req.body;
    let userData = await Client.findOne({
      where: {
        email: email,
        user_status: 1,
      },
    });

    if (!userData) {
      return res
        .status(400)
        .json({ status: 400, message: "email does not exist", data: null });
    }
    let userDb = await middle(userData.db_name, req, res);
    const isSame = await bcrypt.compare(password, userData.password);
    let platformData = [];
    if (userData && isSame) {
      userData = await userDb.users.findOne({
        where: {
          email: email,
        },
      });

      if (userData.isDB) {
        platformData = await userDb.platform.findAll({
          where: {
            is_active: true,
          },
        });
      } else {
        platformData = await userDb.platform.findAll({
          where: {
            is_active: true,
          },
          include: [
            {
              model: userDb.userPlatform,
              where: {
                actions: true,
                user_id: userData.user_id,
              },
              required: true,
            },
          ],
        });
      }

      // creating token
      let token = jwt.sign(
        {
          id: userData.user_id,
          db_name: userData.db_name,
          user_code: userData.user_code,
        },
        process.env.CLIENT_SECRET,
        {
          expiresIn: process.env.expiresIn,
        }
      );

      // get profile of admin
      const Logo = await Client.findAll({
        where: {
          isDB: true,
          db_name: userData.db_name
        },
        attributes: ['logo', 'sidebar_color', 'button_color', 'top_nav_color']
      });
      await userDb.sequelize.close();
      return res.status(200).json({ userData, token, platformData, Logo });
    } else {
      return res.status(400).json({ status: 400, message: "Auth Failed" });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "Something went wrong" });
  }
};

exports.game = async (req, res) => {
  try {
    let { game_name } = req.body;
    let gameData = await req.config.games.create({ game_name });
    if (gameData) {
      await req.config.sequelize.close();
      return res
        .status(200)
        .json({ status: 200, message: "game list", data: gameData });
    } else {
      await req.config.sequelize.close();
      return res.status(400).json({ status: 400, message: "Auth Failed" });
    }
  } catch (error) {
    await req.config.sequelize.close();
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.getGame = async (req, res) => {
  try {
    let gameData = await req.config.games.findAll();
    if (gameData) {
      await req.config.sequelize.close();
      return res.status(200).json({ gameData });
    } else {
      await req.config.sequelize.close();
      return res.status(400).json({ status: 400, message: "Auth Failed" });
    }
  } catch (error) {
    await req.config.sequelize.close();
    return res.status(400).json({ message: error });
  }
};

exports.getClients = async (req, res) => {
  try {
    let ClientData;
    if (req.query.id) {
      ClientData = await Client.findOne({
        where: {
          user_id: req.query.id,
        },
        include: [
          {
            model: db.clientPlatform,
            attributes: ["client_id", "actions", "c_p_id"], // Changed to array
            where: {
              client_id: req.query.id,
            },
            include: {
              model: db.platform,
              attributes: ["platform_name", "platform_id"], // Changed to array
            },
            raw: true,
          },
        ],
        attributes: {
          exclude: ["password"],
        },
      });
    } else {
      ClientData = await Client.findAll({
        where: {
          isDB: true,
        },
        order: [["user_id", "DESC"]],
      });
    }

    return res
      .status(200)
      .json({ status: 200, message: "client list", data: ClientData });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.givePermission = async (req, res) => {
  try {
    let data = req.body.permissionData;

    data.map((item, i) => {
      item.user_id = req.body.user_id;
    });

    let user_id = req.body.user_id;


    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      const findClientPermission = await db.clientPermissions.findOne({
          where: {
            user_id: element.user_id,
            menu_id: element.menu_id,
          },
        });

        if (findClientPermission == null) {
          const UserPermissionInProgramData = await db.clientPermissions.create(
            {
              menu_id: element.menu_id,
              user_id: element.user_id,
              actions: element.is_active,
              menu_name: element.menu_name,
              parent_id: element.parent_id,
            }
          );
        } else {
          const UserPermissionInProgramData = await db.clientPermissions.update(
            {
              actions: element.actions,
            },
            {
              where: {
                user_id: element.user_id,
                menu_id: element.menu_id,
              },
            }
          );
        }
    }


    // Promise.allSettled(
    //   data.map(async (item, i) => {
    //     const findClientPermission = await db.clientPermissions.findOne({
    //       where: {
    //         user_id: req.body.user_id,
    //         menu_id: item.menu_id,
    //       },
    //     });

    //     if (findClientPermission == null) {
    //       const UserPermissionInProgramData = await db.clientPermissions.create(
    //         {
    //           menu_id: item.menu_id,
    //           user_id: user_id,
    //           actions: item.is_active,
    //           menu_name: item.menu_name,
    //           parent_id: item.parent_id,
    //         }
    //       );
    //     } else {
    //       const UserPermissionInProgramData = await db.clientPermissions.update(
    //         {
    //           actions: item.actions,
    //         },
    //         {
    //           where: {
    //             user_id: user_id,
    //             menu_id: item.menu_id,
    //           },
    //         }
    //       );
    //     }
    //   })
    // );

    //open connection the close  after the work done

    let Userdb = await first(req.body.db_name, req, res);
    let clientData = await Userdb.menus.bulkCreate(data, {
      updateOnDuplicate: [
        "menu_id",
        "is_active",
        "menu_name",
        "parent_id",
        "link",
        "icon_path",
        "menu_type",
      ],
    });

    await Userdb.sequelize.close();
    return res
      .status(200)
      .json({ status: 200, message: "permission granted", data: null });
  } catch (error) {
    console.log("error", error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

let AllData = []; // store all Menu Data

const child = (item, i) => {
  let newobj = item;

  var countChild = AllData.filter((obj, j) => {
    return item.menu_id == obj.parent_id;
  });

  // invoking the call back function

  if (countChild.length > 0) {
    countChild.map((ele, i) => {
      let data = child(ele, i);
      if (newobj["children"] !== undefined) {
        newobj.children.push(data);
      } else {
        newobj.children = [data];
      }
    });
    return newobj;
  } else {
    newobj.children = [];
    return newobj;
  }
};

exports.ViewPermissionOfClients = async (req, res) => {
  try {
    let menu_type = req.query.pf || "CRM";
    let ClientMenuData = await db.sequelize.query(
      `Call procClientMenu(:client_id , 'admin_wise' , 'aa', :menu_type)`,
      {
        replacements: { client_id: req.query.id, menu_type },
        type: QueryTypes.INSERT,
      }
    );

    if (ClientMenuData.length > 0) {
      AllData = ClientMenuData; // storing all the cats data
      var parent_data = ClientMenuData.filter((obj, j) => {
        return obj.parent_id == 0;
      });

      var newArr = []; // storing tree data

      // initializing the child method first time

      parent_data.map((item, i) => {
        let finalData = child(item, i);
        newArr.push(finalData);
      });
    }

    return res
      .status(200)
      .json({ status: 200, message: "client Data", data: newArr });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.viewMenu = async (req, res) => {
  try {
    let menu_type = req.query.id || "CRM";
    let menuData = await db.sequelize.query(
      `Call procClientMenu(:client_id , 'viewMenu' , 'aa', :menu_type)`,
      {
        replacements: { client_id: 0, menu_type },
        type: QueryTypes.INSERT,
      }
    );

    if (menuData.length > 0) {
      AllData = menuData; // storing all the cats data
      var parent_data = menuData.filter((obj, j) => {
        return obj.parent_id == 0;
      });

      var newArr = []; // storing tree data

      // initializing the child method first time

      parent_data.map((item, i) => {
        let finalData = child(item, i);
        newArr.push(finalData);
      });
    }

    return res
      .status(200)
      .json({ status: 200, message: "menu Data", data: newArr });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.addMenuInSuperAdmin = async (req, res) => {
  try {
    let { menuBody } = req.body;
    let menuData = await db.menus.create(menuBody);
    return res
      .status(200)
      .json({ status: 200, message: "menu Data", data: menuData });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.addMenuIconInSuperAdmin = async (req, res) => {
  try {
    let { path, m_id } = req.body;
    const data = await fileUpload.imageExport(req, res, path);
    if (!data.message) {
      let updatedIcon = await db.menus.update(
        { icon_path: data },
        {
          where: {
            menu_id: m_id,
          },
        }
      );
      return res
        .status(200)
        .json({ status: 200, message: "menu Data", data: updatedIcon });
    } else {
      return res
        .status(400)
        .json({ status: 400, message: "something went wrong" });
    }
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.updateMenu = async (req, res) => {
  try {
    let { menuBody } = req.body;
    let menuData = await db.menus.update(menuBody, {
      where: {
        menu_id: menuBody.menu_id,
      },
    });
    return res
      .status(200)
      .json({
        status: 200,
        message: "menu Data updated successfully",
        data: [],
      });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.clientUpdate = async (req, res) => {
  try {
    let clientData = req.body;

    let userData = await db.clients.findOne({
      where: {
        user_code: clientData.user_code,
      },
    });

    if (!userData) {
      return res.status(400).json({ status: 400, message: "admin not found" });
    }

    let userDb = await first(userData.db_name, req, res);

    if (clientData.password) {
      clientData.password = await bcrypt.hash(clientData.password, 10);
    }

    let data = {
      CRM: clientData.isCRM || true,
      DMS: clientData.isDMS || false,
      SALES: clientData.isSALES || false,
      CHANNEL: clientData.isCHANNEL || false,
    };

    // update client permission at superadmin
    const entries = Object.entries(data);
    for (const [index, [key, value]] of entries.entries()) {
      await db.clientPlatform.update(
        { actions: value },
        { where: { client_id: userData.user_id, platform_id: index + 1 } }
      );
    }

    // update client permission at superadmin
    const Userentries = Object.entries(data);
    for (const [index, [key, value]] of Userentries.entries()) {
      await userDb.platform.update(
        { is_active: value },
        { where: { platform_id: index + 1 } }
      );
    }

    if (req.files && req.files.logo) {
        req.body._imageName = userData.logo || 0
       let name = await fileUpload.imageExport(req, res, "logo", "logo");
       clientData.logo = name
    }

    if (req.files && req.files.client_image_1) {
      req.body._imageName = userData.client_image_1 || 0
      let client_image_1 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_1");
      clientData.client_image_1 = client_image_1;
    }

    if (req.files && req.files.client_image_2) {
      req.body._imageName = userData.client_image_2 || 0
      let client_image_2 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_2");
      clientData.client_image_2 = client_image_2;
    }

    if (req.files && req.files.client_image_3) {
      req.body._imageName = userData.client_image_3 || 0
      let client_image_3 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_3");
      clientData.client_image_3 = client_image_3;
    }

    if (req.files && req.files.client_image_4) {
      req.body._imageName = userData.client_image_4 || 0
      let client_image_4 =  await fileUpload.imageExport(req, res, "clientdoc", "client_image_4");
      clientData.client_image_4 = client_image_4;
    }


    await db.clients.update(clientData, {
      where: {
        user_code: clientData.user_code,
      },
    });

    // find user from client table

    let clientUser = await userDb.users.findOne({
      where: {
        user_code: clientData.user_code,
      },
    });

    // update user menu table in user personal db

    clientData.user_id = clientUser.user_id;

    await userDb.users.update(clientData, {
      where: {
        user_code: clientData.user_code,
      },
    });

    // find user profile
    let clientUserProfile = await userDb.usersProfiles.findOne({
      where: {
        user_id: clientUser.user_id,
      },
    });

    if (clientData.pan) {
      let profileData = {
        pan_no: clientData.pan,
      };
      await clientUserProfile.update(profileData);
    }

    // update platform
    let clientProf = await db.clients.findOne({
      where: {
        user_code: clientData.user_code,
      },
    });
    await userDb.sequelize.close();
    return res
      .status(200)
      .json({ status: 200, message: "client Data Updated", data:clientProf });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.getPlatformPermissionByAdmin = async (req, res) => {
  try {
    let platformData = await db.clientPlatform.findAll({
      where: {
        actions: true,
        client_id: req.query.id,
      },
    });

    return res
      .status(200)
      .json({
        status: 200,
        message: "client platFormData",
        data: platformData,
      });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.clientDelete = async (req, res) => {
  try {
    let clientID = req.query.id;
    let userData = await db.clients.findOne({
      where: {
        user_id: clientID,
      },
    });

    if (!userData) {
      return res.status(400).json({ status: 400, message: "user not found" });
    }

    if (userData.isDB) {
      await db.clients.update(
        { user_status: false },
        {
          where: {
            db_name: userData.db_name,
          },
        }
      );
    } else {
      await db.clients.update(
        { user_status: false },
        {
          where: {
            user_code: userData.user_code,
          },
        }
      );
    }
    return res
      .status(200)
      .json({
        status: 200,
        message: "client deactivated successfully",
        data: null,
      });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.getCountry = async (req, res) => {
  try {
    let areaData = await db.country.findAll();
    return res
      .status(200)
      .json({ status: 200, message: "Country List", data: areaData });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};
exports.storeCountry = async (req, res) => {
  try {
    const data = await db.country.findOne({
      where: {
        country_name: db.country_name,
      },
    });
    if (data)
      return res
        .status(400)
        .json({ status: 400, message: "country name already exist" });
    let areaData = await db.country.create(req.body);
    return res
      .status(200)
      .json({ status: 200, message: "Country craeted", data: areaData });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.editCountry = async (req, res) => {
  try {
    const data = await db.country.findOne({
      where: {
        country_name: req.body.country_name,
        country_id: { [Op.ne]: req.body.country_id },
      },
    });
    if (data)
      return res
        .status(400)
        .json({ status: 400, message: "country name already exist" });
    await req.config.country.update(req.body, {
      where: {
        country_id: req.body.country_id,
      },
    });
    return res
      .status(200)
      .json({ status: 200, message: "Country updated", data: null });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.deleteCountry = async (req, res) => {
  try {
    let areaData = await db.country.findOne({
      where: {
        country_id: req.query.cnt_id,
      },
    });
    if (!areaData)
      return res
        .status(404)
        .json({ status: 400, message: "country name not found" });
    await areaData.destroy();
    return res
      .status(200)
      .json({ status: 200, message: "Country deleted", data: null });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.getState = async (req, res) => {
  try {
    let stateData = await db.states.findAll({
      where: {
        country_id: req.query.cnt_id,
      },
    });
    return res
      .status(200)
      .json({ status: 200, message: "State List", data: stateData });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};
exports.storeStates = async (req, res) => {
  try {
    const data = await db.states.findOne({
      where: {
        country_id: req.body.country_id,
        state_name: req.body.state_name,
      },
    });
    if (data)
      return res
        .status(400)
        .json({ status: 400, message: "state name already exist" });
    let stateData = await db.states.create(req.body);
    return res
      .status(400)
      .json({ status: 200, message: "state name created successfully" });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.editStates = async (req, res) => {
  try {
    const data = await db.findOne({
      where: {
        country_id: req.body.country_id,
        state_name: req.body.state_name,
        state_id: { [Op.ne]: req.body.state_id },
      },
    });
    if (data)
      return res
        .status(400)
        .json({ status: 400, message: "state name already exist" });

    await db.states.update(req.body, {
      where: {
        state_id: req.body.state_id,
      },
    });
    return res
      .status(400)
      .json({ status: 200, message: "state name updated successfully" });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.deleteStates = async (req, res) => {
  try {
    let stateData = await db.states.findOne({
      where: {
        state_id: req.query.st_id,
      },
    });
    if (!stateData)
      return res
        .status(400)
        .json({ status: 400, message: "state name does not existed" });

    await stateData.destroy();
    return res
      .status(400)
      .json({ status: 200, message: "state name deleted successfully" });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.getCityAndDistrict = async (req, res) => {
  try {
    let cityData = await db.city.findAll({
      where: {
        state_id: req.query.st_id,
      },
    });
    let distictData = await db.district.findAll({
      where: {
        state_id: req.query.st_id,
      },
    });

    let cityDistict = {
      cityData,
      distictData,
    };
    return res
      .status(200)
      .json({
        status: 200,
        message: "city and district List",
        data: cityDistict,
      });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.storeCity = async (req, res) => {
  try {
    const data = await db.city.findOne({
      where: {
        state_id: req.body.state_id,
        city_name: req.body.city_name,
      },
    });
    if (data)
      return res
        .status(400)
        .json({ status: 400, message: "City name already exist" });
    let cityData = await db.city.create(req.body);
    return res
      .status(400)
      .json({
        status: 200,
        message: "City created successfuly",
        data: cityData,
      });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.editCity = async (req, res) => {
  try {
    const data = await db.city.findOne({
      where: {
        state_id: req.body.state_id,
        city_name: req.body.city_name,
        city_id: { [Op.ne]: req.body.city_id },
      },
    });
    if (data)
      return res
        .status(400)
        .json({ status: 400, message: "City name already exist" });
    await db.city.update(req.body, {
      where: {
        city_id: req.body.city_id,
      },
    });
    return res
      .status(400)
      .json({ status: 200, message: "City name updated successfully" });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.deleteCity = async (req, res) => {
  try {
    let cityData = await db.city.findOne({
      where: {
        city_id: req.query.ct_id,
      },
    });
    if (!cityData)
      return res
        .status(400)
        .json({ status: 400, message: "City name does not exist" });
    await cityData.destroy();
    return res.status(400).json({ status: 200, message: "City deleted" });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.getClientByUrl = async (req, res) => {
  try {
    let ClientData;
    let newURL = req.body.client_url ;
    if(req.body.client_url){
      if(req.body.client_url.charAt(req.body.client_url.length-1) === '/'){
        newURL = req.body.client_url.substring(0,req.body.client_url.length-1)
      }
    }

    console.log(newURL)
  
      ClientData = await Client.findOne({
        where: {
          client_url: newURL,
        },
        
        attributes: {
          exclude: ["password"],
        },
      });
    

    return res
      .status(200)
      .json({ status: 200, message: "client Data", data: ClientData });
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};
