const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const { responseError, responseSuccess } = require("../helper/responce");
const fs = require("fs");
const path = require("path");
const xlsx = require("xlsx");
const sendEmail = require("../common/mailer");
const FieldModel = require("../model/FieldModel");

// crerate new accounts
exports.storeAccount = async (req, res) => {
  const process = await req.config.sequelize.transaction();
  try {
    let accountBody = req.body;
    let accountData = await req.config.accounts.findOne({
      where: { acc_name: accountBody.acc_name },
    },{ transaction: process });

        if(accountData) {
          await process.cleanup()
          return await responseError(req, res, "accounts already created ")
        }
        let count  = await req.config.accounts.count({ paranoid: false })
        accountBody.acc_code = `ACC_00${count}`

        if(req.query.l_id){
            let lead_data = await req.config.leads.findOne({where:{lead_id : req.query.l_id }})

            accountBody = { ...accountBody ,
                acc_owner: lead_data.dataValues.lead_owner,
                contact_no: lead_data.dataValues?.p_contact_no,
                bill_cont: lead_data.dataValues?.country_id,
                bill_state: lead_data.dataValues?.state_id,
                bill_city: lead_data.dataValues?.city_id,
                bill_pincode: lead_data.dataValues?.pincode,   
                ship_cont: lead_data.dataValues?.country_id,
                ship_state: lead_data.dataValues?.state_id,
                ship_city: lead_data.dataValues?.city_id,
                ship_pincode: lead_data.dataValues?.pincode,
                ship_address: lead_data.dataValues?.address,
                assigned_to: lead_data.dataValues?.assigned_lead

            }
        }
    
        const config = await req.config.emailConfig.findAll();
        accountData =  await req.config.accounts.create(accountBody, {transaction: process})
        await process.commit();

        const resetLink = `Account created with account name ${accountBody.acc_name} and account id ${accountBody.acc_code}`;
        const htmlTemplatePath = path.join(
          __dirname,
          "..",
          "mail",
          "cp",
          "example.html"
        );

        const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
    const htmlContent = htmlTemplate.replace("{{resetLink}}", resetLink);
    const htmlContent1 = htmlContent.replace("{{mode}}", `Account Created`);

    const accountOwnerDetail = await req.config.users.findByPk(accountBody.acc_owner);
        let option = {
          subject: "New Account Created",
          message: htmlContent1,
          email: accountOwnerDetail.email
        };
        if(config.length > 0){
          option = {...option, 
            host:config[0].host,
            port:config[0].port,
            user:config[0].user,
            pass:config[0].password,
            from:config[0].from,
          }
        }

    await sendEmail(option);
        return await responseSuccess(req, res, "accounts created Succesfully", accountData)
       
    } catch (error) {
        console.log(error)
        await process.rollback();
        return await responseError(req, res, "something went wrong")
    }
}

exports.downloadExcelData = async (req, res) => {
  try {
    let whereClause = {};
    let commonExclude = ["createdAt", "updatedAt", "deletedAt"];
    if (!req.user.isDB) {
      whereClause = {
        [Op.or]: [
          { acc_owner: req.user.user_id },
          { assigned_to: req.user.user_id },
        ],
      };
    }
    let accounts = await req.config.accounts.findAll({
      where: whereClause,
      attributes: [
        "acc_id",
        "acc_name",
        "acc_code",
        "parent_id",
        "website",
        "contact_no",
        "emp_name",
        "desc",
        "bill_pincode",
        "acc_owner",
        "ship_pincode",
        "ship_address",
        "parent_name",
        "assigned_to",
        [
          req.config.sequelize.fn(
            "count",
            req.config.sequelize.col("db_leads.acc_id")
          ),
          "lead_count",
        ],
      ],
      include: [
        { model: req.config.leads, required: false, paranoid: false },
        { model: req.config.accountTypes, paranoid: false },
        { model: req.config.industry, paranoid: false },
        {
          model: req.config.users,
          as: "account_owner",
          attributes: ["user_id", "user"],
          paranoid: false,
        },

        {
          model: req.config.users,
          as: "assignedAcc",
          attributes: ["user_id", "user"],
          paranoid: false,
        },
        {
          model: req.config.country,
          as: "billCountry",
          attributes: {
            exclude: commonExclude,
          },
          paranoid: false,
        },
        {
          model: req.config.states,
          as: "billState",
          attributes: {
            exclude: commonExclude,
          },
          paranoid: false,
        },

        {
          model: req.config.city,
          as: "billCity",
          attributes: {
            exclude: commonExclude,
          },
          paranoid: false,
        },
        {
          model: req.config.country,
          as: "shipCountry",
          attributes: {
            exclude: commonExclude,
          },
          paranoid: false,
        },
        {
          model: req.config.states,
          as: "shipState",
          attributes: {
            exclude: commonExclude,
          },
          paranoid: false,
        },

        {
          model: req.config.city,
          as: "shipCity",
          attributes: {
            exclude: commonExclude,
          },
          paranoid: false,
        },
      ],
      group: ["acc_id"],
      order: [["acc_id", "DESC"]],
    });
    //console.log("lead", lead[0].dataValues?.db_department.dataValues?.department)
    // console.log('lead', lead);
    let excelClientData = [];
    accounts?.forEach((element) => {
      let item = {
        Name: element?.dataValues?.acc_name,
        "Account Code": element?.dataValues?.acc_code,
        Type: element?.dataValues?.db_account_type?.dataValues
          ?.account_type_name,
        Website: element?.dataValues?.website,
        Owner: element?.dataValues?.account_owner?.dataValues?.user,
        "Assigned To": element?.dataValues?.assignedAcc?.dataValues?.user,
        "Lead Count": element?.dataValues?.lead_count,
        "Parent name": element?.dataValues?.parent_name,
        "Contact no": element?.dataValues?.contact_no,
        Employee: element?.dataValues?.emp_name,
        Industry: element?.dataValues?.db_industry?.dataValues?.industry,
        Description: element?.dataValues?.desc,
        "Billing Country":
          element?.dataValues?.billCountry?.dataValues?.country_name,
        "Billing State": element?.dataValues?.billState?.dataValues?.state_name,
        "Billing City": element?.dataValues?.billCity?.dataValues?.city_name,
        "Billing Pincode": element?.dataValues?.bill_pincode,
        "Shipping Country":
          element?.dataValues?.shipCountry?.dataValues?.country_name,
        "Shipping State":
          element?.dataValues?.shipState?.dataValues?.state_name,
        "Shipping City": element?.dataValues?.shipCity?.dataValues?.city_name,
        "Shipping Pincode": element?.dataValues?.ship_pincode,
        "Shipping Address": element?.dataValues?.ship_address,
      };
      excelClientData.push(item);
    });
    // let excelClientData = lead?.map((item)=> item.dataValues?)
    const workbook = xlsx.utils.book_new();
    const worksheet = xlsx.utils.json_to_sheet(excelClientData);
    // Add the worksheet to the workbook
    xlsx.utils.book_append_sheet(workbook, worksheet, "Sheet1");

    // Generate a temporary file path to save the Excel workbook
    const tempFilePath = path.join(
      __dirname,
      `../uploads/temp`,
      "temp.xlsx"
    );

    // Write the workbook to a file
    xlsx.writeFile(workbook, tempFilePath);

    // Set the response headers
    res.setHeader("Content-Type", "application/vnd.ms-excel");
    res.setHeader("Content-Disposition", "attachment; filename=example.xlsx");

    // Stream the file to the response
    const stream = fs.createReadStream(tempFilePath);
    stream.pipe(res);

    // Delete the temporary file after sending the response
    stream.on("end", () => {
      fs.unlinkSync(tempFilePath);
    });
    await req.config.sequelize.close();
    return;
  } catch (error) {
    console.log(error);
    return res
      .status(400)
      .json({ status: 400, message: "Something went wrong" });
  }
};

// get accounts
exports.getAccount = async (req, res) => {
  try {
    let accounts;
    let whereClause = {};
    let commonExclude = ["createdAt", "updatedAt", "deletedAt"];
    if (!req.user.isDB) {
      whereClause = {
        [Op.or]: [
          { acc_owner: req.user.user_id },
          { assigned_to: req.user.user_id },
        ],
      };
    }

    // if account id is provided then single query
    if (req.query.acc_id) {
      accounts = await req.config.accounts.findOne({  
        where: {
          acc_id: req.query.acc_id,
        },
        include: [
          { model: req.config.accountField, separate:true, paranoid: false, order:[['field_order', 'ASC']] },
          { model: req.config.accountTypes, paranoid: false },
          { model: req.config.industry, paranoid: false },
          {
            model: req.config.users,
            as: "account_owner",
            attributes: ["user_id", "user"],
            paranoid: false,
          },
          {
            model: req.config.users,
            as: "assignedAcc",
            attributes: ["user_id", "user"],
            paranoid: false,
          },
          {
            model: req.config.country,
            as: "billCountry",
            attributes: {
              exclude: commonExclude,
            },
            paranoid: false,
          },
          {
            model: req.config.states,
            as: "billState",
            attributes: {
              exclude: commonExclude,
            },
            paranoid: false,
          },

                {model: req.config.city, as: "billCity" ,  attributes: {
                    exclude:commonExclude
                },paranoid: false, },
                {model: req.config.country, as: "shipCountry" ,  attributes: {
                    exclude:commonExclude
                },paranoid: false, },
                {model: req.config.states, as: "shipState" ,  attributes: {
                    exclude:commonExclude
                },paranoid: false, },

                {model: req.config.city, as: "shipCity" ,  attributes: {
                    exclude:commonExclude
                },paranoid: false, },

                {
                  model: req.config.contacts,
                  as:"contactList",
                   attributes: [
                      "contact_id",
                      "first_name", 
                      "middle_name",
                      "last_name",
                  ]
                },
              
                {
                  model: req.config.opportunities,
                  as:"oppList",
                   attributes: [
                      "opp_id",
                      "opp_name",
                      "amount"
                  ]
                }, 
              {
                  model: req.config.leads,
                   attributes: [
                      "lead_id",
                      "lead_name",
                      "createdAt"
                  ]
              }

                
            ],order: [
                ['acc_id', 'DESC']
              ]
            })
        }else{
            accounts = await req.config.accounts.findAll({
                where: whereClause,
                attributes: [
                'acc_id', 'acc_name', "acc_code", "parent_id", "website",
                'contact_no', 'emp_name', 'desc', 'bill_pincode','acc_owner',
                'ship_pincode', 'ship_address', 'parent_name','assigned_to',
                [req.config.sequelize.fn('count', req.config.sequelize.col('db_leads.acc_id')), 'lead_count']
                ],
                include: [
                    {model: req.config.leads, required:false  ,paranoid: false},
                    {model: req.config.accountTypes, paranoid: false,}, 
                    {model: req.config.industry, paranoid: false,},
                    {model: req.config.users, as: "account_owner" ,  attributes: ['user_id', 'user'],paranoid: false, },
                    {model: req.config.users, as: "assignedAcc" ,  attributes: ['user_id', 'user'],paranoid: false, },
                    {model: req.config.country, as: "billCountry" ,  attributes: {
                        exclude:commonExclude
                    },paranoid: false, },
                    {model: req.config.states, as: "billState" ,  attributes: {
                        exclude:commonExclude
                    },paranoid: false, },
    
                    {model: req.config.city, as: "billCity" ,  attributes: {
                        exclude:commonExclude
                    },paranoid: false, },
                    {model: req.config.country, as: "shipCountry" ,  attributes: {
                        exclude:commonExclude
                    },paranoid: false, },
                    {model: req.config.states, as: "shipState" ,  attributes: {
                        exclude:commonExclude
                    },paranoid: false, },
    
                    {model: req.config.city, as: "shipCity" ,  attributes: {
                        exclude:commonExclude
                    },paranoid: false, },
                    {
                        model: req.config.contacts,
                        as:"contactList",
                         attributes: [
                            "contact_id",
                            "first_name", 
                            "middle_name",
                            "last_name",
                        ]
                    },
                    
                    {
                        model: req.config.opportunities,
                        as:"oppList",
                         attributes: [
                            "opp_id",
                            "opp_name",
                            "amount"
                        ]
                    }, 
                    {
                        model: req.config.leads,
                         attributes: [
                            "lead_id",
                            "lead_name",
                            "createdAt"
                        ]
                    }

                ],
                group: ['acc_id'],
            order: [
                ['acc_id', 'DESC']
              ],
             
            })
        }   
        await responseSuccess(req, res, "accounts list", accounts)
       
    } catch (error) {
        console.log(error)
        return await responseError(req, res, "something went wrong")
    }
 
};

let AllData = []; // store all Menu Data

const child = (item, i) => {
  let newobj = item;

  var countChild = AllData.filter((obj, j) => {
    return item.acc_id == obj.parent_id;
  });

  // invoking the call back function

  if (countChild.length > 0) {
    countChild.map((ele, i) => {
      let data = child(ele, i);
      if (newobj["children"] !== undefined) {
        newobj.children.push(data);
      } else {
        newobj.children = [data];
      }
    });
    return newobj;
  } else {
    newobj.children = [];
    return newobj;
  }
};

exports.getTreeAccount = async (req, res) => {
  try {
    let accounts = await req.config.sequelize.query(
      "SELECT acc_id, acc_name, parent_id, parent_name FROM db_accounts where deletedAt is null",
      {
        type: QueryTypes.SELECT,
      }
    );

    if (accounts.length > 0) {
      AllData = accounts; // storing all the cats data
      var parent_data = accounts.filter((obj, j) => {
        return obj.parent_id == 0;
      });

      var newArr = []; // storing tree data

      // initializing the child method first time

      parent_data.map((item, i) => {
        let finalData = child(item, i);
        newArr.push(finalData);
      });

      return responseSuccess(req, res, "ccount list", newArr);
    } else {
      return responseSuccess(req, res, "account list", accounts);
    }
  } catch (error) {
    console.log(error);
    return await responseError(req, res, "something went wrong");
  }
};

exports.editAccount = async (req, res) => {
  const process = await req.config.sequelize.transaction();
  try {
    let accountBody = req.body;
    let accountData = await req.config.accounts.findOne({
      where: {
        acc_id: accountBody.acc_id,
      },
    },{ transaction: process });

    if (!accountData) {
      await process.cleanup()
      return await responseError(req, res, "no accounts exist");}

    let accountCheckData = await req.config.accounts.findOne({
      where: {
        acc_name: accountBody.acc_name,
        acc_id: { [Op.ne]: accountBody.acc_id },
      },
    });

    if (accountCheckData)
      return await responseError(req, res, "accounts name data exist");


    const config = await req.config.emailConfig.findAll();
   
    await req.config.accounts.update(accountBody, {
      where: {
        acc_id: accountBody.acc_id,
      },
      transaction: process,
    });
    await process.commit();

          
          const resetLink = `Account Edited with account name ${accountBody.acc_name} and account id ${accountBody.acc_code}`;

          const htmlTemplatePath = path.join(
            __dirname,
            "..",
            "mail",
            "cp",
            "example.html"
          );

          const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
          const htmlContent = htmlTemplate.replace("{{resetLink}}", resetLink);
          const htmlContent1 = htmlContent.replace("{{mode}}", `Account Edited`);

          const accountOwnerDetail = await req.config.users.findByPk(accountBody.acc_owner);
          let option = {
            subject: "Account Edited",
            message: htmlContent1,
            email: accountOwnerDetail.email
          };
          if(config.length > 0){
            option = {...option, 
              host:config[0].host,
              port:config[0].port,
              user:config[0].user,
              pass:config[0].password,
              from:config[0].from,
            }
          }
          
          await sendEmail(option);

    return await responseSuccess(req, res, "accounts status updated");
  } catch (error) {
    console.log(error);
    await process.rollback();
    return await responseError(req, res, "something went wrong");
  }
};

exports.deleteAccount = async (req, res) => {
  try {
    let { acc_id } = req.query;
    let accountData = await req.config.accounts.findOne({
      where: {
        acc_id: acc_id,
      },
    });

    if (!accountData)
      return await responseError(req, res, "accounts does not existed");
    await accountData.destroy();
    return await responseSuccess(req, res, "accounts deleted");
  } catch (error) {
    console.log(error);
    return await responseError(req, res, "something went wrong");
  }
};

exports.storeaccountField=async(req,res)=>{

  try {
    const accFieldBody = req.body
    let accFieldData = await req.config.accountField.bulkCreate(accFieldBody, {updateOnDuplicate: ["acc_field_id","field_lable","acc_id","field_name", "field_order", "option", "input_value", "input_type", "field_type", "field_size"]
 });
    await responseSuccess(req, res, "acc extra data submitted successfully", accFieldData)
} catch (error) {
console.log(error)

  await responseError(req, res, "Something went wrong")
}
}

exports.getaccountField=async(req,res)=>{
  try {
    const AccData = await req.config.accountField.findAll({
    })
    await responseSuccess(req, res, "Account Data", AccData)
} catch (error) {
console.log(error)
await responseError(req, res, "Something went wrong")
}
}

