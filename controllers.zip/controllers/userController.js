const { Sequelize, DataTypes, QueryTypes, where, Op } = require("sequelize");
const { responseError, responseSuccess } = require("../helper/responce");
const bcrypt = require("bcryptjs");
const db = require("../model");
const crypto = require("crypto");
const fileUpload = require("../common/imageExport");
const { first } = require("../connectionResolver/firstConnection");
const sendEmail = require("../common/mailer");
const moment = require("moment");
const jwt = require("jsonwebtoken");
const { BASE_URL } = require("../config/constant");
const path = require("path");
var fs = require("fs");
const { promisify } = require("util");
const { group } = require("console");
require("dotenv").config();





const randomCodeGenrator = (name) => {
  var result = "";
  result = Math.floor(10000000 + Math.random() * 90000000);
  var code = name + result;
  return code;
};

const randomSixCodeGenrator = () => {
  var result = "";
  result = Math.floor(100000 + Math.random() * 900000);
  return result;
};

const buildTree = (auth, parentId, dashNavArr) => {
  const children = AllData.filter((item) => item.parent_id == parentId);
  children.forEach((child) => {
    if (auth && child.is_active == 1) {
      dashNavArr.push(child);
    } else {
      if (child.actions == 1) {
        dashNavArr.push(child);
      }
    }
    if (dashNavArr.length > 0) {
      return dashNavArr;
    } else {
      return dashNavArr.concat(buildTree(auth, child.menu_id, dashNavArr)); // Recursive call without assigning to a variable
    }
  });
  return dashNavArr;
};

exports.totalUser = async (req, res) => {
  try {
    const count = await req.config.users.count({
      where: {
        isDB: false,
      },
    });

    let clientAdmin = await db.clients.findOne({
      where: {
        db_name: db_name,
        isDB: true,
      },
    });

    const countData = {
      userCount: count,
      no_of_license: clientAdmin.no_of_license,
    };

    return await responseSuccess(req, res, "user list count", countData);
  } catch (error) {
    return await responseError(req, res, "something went wrong");
  }
};

exports.createUser = async (req, res) => {
  const processClient = await req.config.sequelize.transaction();
  const DBprocess = await db.sequelize.transaction();
  try {
    let { email, role_id, isCRM, isDMS, isSALES, isCHANNEL } = req.body;

    // find cliend admin db
    let clientAdmin = await db.clients.findOne(
      {
        where: {
          db_name: req.user.db_name,
          isDB: true,
        },
      },
      { transaction: processClient }
    );

    // if (clientAdmin.dataValues.domain != null) {
    //   if (clientAdmin.domain.split("@")[1] != email.split("@")[1]) {
    //     await processClient.cleanup();
    //     await DBprocess.cleanup();
    //     return res
    //       .status(400)
    //       .json({ status: 400, message: "domain does not match" });
    //   }
    // }

    let userCode = randomCodeGenrator("USER");
    let userPassword = await bcrypt.hash(userCode, 10);
    let data = req.body;
    data.password = userPassword;
    data.isDB = false;
    data.user_code = userCode;
    let userData;
    userData = await db.clients.findOne(
      {
        where: {
          db_name: req.user.db_name,
          email: email,
        },
      },
      { transaction: processClient }
    );

    if (userData) {
      await processClient.rollback();
      await DBprocess.rollback();
      await processClient.cleanup();
      await DBprocess.cleanup();
      await req.config.sequelize.close();
      return res
        .status(400)
        .json({ status: 400, message: "user existed in this db" });
    } else {
      // check if licese exxced or not

      const count = await req.config.users.count({
        where: {
          isDB: false,
        },
      });

      if (count >= clientAdmin.no_of_license) {
        await processClient.rollback();
        await DBprocess.rollback();
        await processClient.cleanup();
        await DBprocess.cleanup();
        return await responseError(
          req,
          res,
          "cannot add more user, user count exceed the license count"
        );
      }

      data.subscription_start_date =
        clientAdmin.dataValues.subscription_start_date;
      (data.subscription_end_date =
        clientAdmin.dataValues.subscription_end_date),
        (data.no_of_months = clientAdmin.dataValues.no_of_months);
      data.domain = clientAdmin.dataValues.domain;
      data.no_of_license = clientAdmin.dataValues.no_of_license;
      data.no_of_channel_license = clientAdmin.dataValues.no_of_channel_license;
      data.no_of_dms_license = clientAdmin.dataValues.no_of_dms_license;
      data.no_of_sales_license = clientAdmin.dataValues.no_of_sales_license;
      data.sidebar_color = clientAdmin.dataValues.sidebar_color;
      data.button_color = clientAdmin.dataValues.button_color;
      data.text_color = clientAdmin.dataValues.text_color;
      data.top_nav_color = clientAdmin.dataValues.top_nav_color;
      data.db_name = req.user.db_name;
      if (role_id === 1) {
        data.doc_verification = 0;
        data.isCHANNEL = 1
        isCHANNEL = 1
      } else {
        data.doc_verification = 2;
      }

      if (role_id === 2 || role_id === 3) {
        data.isCHANNEL = 1
        isCHANNEL = 1
      }

      // createing db users and common db users
      userData = await db.clients.create(data, {
        transaction: DBprocess,
      });

      // create platform permission
      let dbUserData = await req.config.users.create(data, {
        transaction: processClient,
      });

      let userPTdata = {
        CRM: isCRM || true,
        DMS: isDMS || false,
        SALES: isSALES || false,
        CHANNEL: isCHANNEL || false,
      };

      // update client permission at client side
      const Userentries = Object.entries(userPTdata);
      for (const [index, [key, value]] of Userentries.entries()) {
        await req.config.userPlatform.create(
          {
            actions: value,
            platform_id: index + 1,
            user_id: dbUserData.user_id,
          },
          { transaction: processClient }
        );
      }

      data.user_id = dbUserData.user_id;

      let userProfileData = await req.config.usersProfiles.create(data, {
        transaction: processClient,
      });

      // sending email for the user

      let option = {};
      if (role_id === 1) {
        let registrationToken = jwt.sign(
          { id: dbUserData.user_id, db_name: req.user.db_name },
          process.env.CLIENT_SECRET,
          {
            expiresIn: process.env.CP_SIGNUP_EXPIRES,
          }
        );

        const signupLink = `${req.admin.client_url}/CHANNEL/Signup?token=${registrationToken}`;
        const htmlTemplatePath = path.join(
          __dirname,
          "..",
          "mail",
          "cp",
          "signup.html"
        );
        const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
        const htmlContent = htmlTemplate.replace("{{signupLink}}", signupLink);
        option = {
          email: email,
          subject: "Kloud Mart",
          message: htmlContent,
        };

        

      } else {
        const resetToken = crypto.randomBytes(32).toString("hex");
        data.password_reset_token = crypto
          .createHash("sha256")
          .update(resetToken)
          .digest("hex");

        
        const resetLink = `${req.admin.client_url}/ChangePassword?tkn=u$34${data.password_reset_token}`;
        const htmlTemplatePath = path.join(
          __dirname,
          "..",
          "mail",
          "cp",
          "welcome.html"
        );

        const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
        const htmlContent = htmlTemplate.replace("{{resetLink}}", resetLink);
        option = {
          email: email,
          subject: "Kloud Mart",
          message: htmlContent,
        };
        console.log("userData", userData)

        let userUpdate = await db.clients.findByPk(userData.dataValues.user_id);
        console.log("userUpdate", userUpdate)
        // await userUpdate.update({
        //   password_reset_token: data.password_reset_token,
        //   password_reset_expires: moment(new Date()).add(1, "d").toDate(),

        // })

        userData = await userData.update({
          password_reset_token: data.password_reset_token,
          password_reset_expires: moment(new Date()).add(1, "d").toDate(),

        }, {
          transaction: DBprocess,
        });
      }
      await sendEmail(option);

      await processClient.commit();
      await DBprocess.commit();

      let send = {
        dbUserData,
        userProfileData,
      };
      return await responseSuccess(req, res, "user created successfully", send);
    }
  } catch (error) {
    await processClient.rollback();
    await DBprocess.rollback();
    await processClient.cleanup();
    await DBprocess.cleanup();
    console.log(error);
    return await responseError(req, res, "something went wrong");
  }
};

exports.uploadsUserImages = async (req, res) => {
  try {
    let { path } = req.body;
    let updateData = req.body;
    const data = await fileUpload.imageExport(req, res, path);
    if (!data.message) {
      if (path === "adh") {
        updateData.aadhar_file = data;
      } else if (path === "pan") {
        updateData.pan_file = data;
      } else if (path === "dl") {
        updateData.dl_file = data;
      } else if (path === "lsUser") {
        updateData.user_image_file = data;
      } else if (path === "cheque") {
        updateData.c_cheque_file = data;
      } else if (path === "rera") {
        updateData.rera_file = data;
      }

      let see = await req.config.usersProfiles.update(updateData, {
        where: {
          user_id: updateData.user_id,
        },
      });
      return await responseSuccess(
        req,
        res,
        "document uploaded successfully",
        see
      );
    } else {
      return await responseError(req, res, "something went wrong");
    }
  } catch (error) {
    return await responseError(req, res, "something went wrong");
  }
};

exports.getAllUserByRole = async (req, res) => {
  try {
    const AlluserRoleWiseCount = await req.config.sequelize.query(
      `SELECT db_users.role_id, db_roles.role_name,COUNT(*) as 'count' from db_roles INNER JOIN db_users ON db_users.role_id = db_roles.role_id WHERE db_users.deletedAt is null GROUP by db_users.role_id`,
      {
        type: QueryTypes.SELECT,
      }
    );
    return await responseSuccess(
      req,
      res,
      "Role wise count",
      AlluserRoleWiseCount
    );
  } catch (error) {
    return await responseError(req, res, "something went wrong");
  }
};

exports.getUsersByRoleID = async (req, res) => {
  try {

    let whereClause = {}
    if(req.query.f_date){
      whereClause.createdAt = {
        [Op.gte]: req.query.f_date, // Greater than or equal to current date at midnight
        [Op.lt]:  req.query.t_date// Less than current date + 1 day at midnight
    }

    }
    let userData = await req.config.users.findAll({
      where: {
        ...whereClause,
        role_id: req.query.role_id,
        doc_verification: 2,
      },
      attributes: ["user_id", "user", "user_code", "createdAt", "report_to", "organisation",  "user_l_name","email", "contact_number", "organisation", "db_name", "isDB", "user_status", "doc_verification", "reject_reason", "role_id", "address", "pincode", 
      [req.config.sequelize.fn('count', req.config.sequelize.col('db_leads.lead_id')), 'lead_count'],
      [req.config.sequelize.fn('count', req.config.sequelize.col('db_leads->visitList.visit_id')), 'visit_count'],
      [req.config.sequelize.fn('count', req.config.sequelize.col('db_leads->BookingLeadList.booking_id')), 'booking_count'],

      ],
      include: [
        {
          model: req.config.usersProfiles,
          include: [
            {
              model: req.config.divisions,
              attributes: {
                exclude: ["createdAt", "updatedAt", "deletedAt"],
              },
            },
            {
              model: req.config.departments,
              attributes: {
                exclude: ["createdAt", "updatedAt", "deletedAt"],
              },
            },
            {
              model: req.config.designations,
              attributes: {
                exclude: ["createdAt", "updatedAt", "deletedAt"],
              },
            },
          ],
        },
        {
          model: req.config.user_role,
          attributes: {
            exclude: ["createdAt", "updatedAt", "deletedAt"],
          },
        },
        {
          model: req.config.country,
          attributes: {
            exclude: ["createdAt", "updatedAt", "deletedAt"],
          },
        },
        {
          model: req.config.states,
          attributes: {
            exclude: ["createdAt", "updatedAt", "deletedAt"],
          },
        },
        {
          model: req.config.city,
          attributes: {
            exclude: ["createdAt", "updatedAt", "deletedAt"],
          },
        },
        {
          model: req.config.users,
          as: 'reportToUser',
          attributes: ['user_id','user']
        },
        {
          model: req.config.leads,
          attributes: ['lead_id', 'lead_name'],
          
          include: [
            {
              model: req.config.leadVisit,
              as: 'visitList',
              attributes: ["visit_id",],

            },
            {
              model: req.config.leadBooking,
              as: 'BookingLeadList',
              attributes: ["booking_id",],

            },
          ],
          group: ['leadAssignedBy.lead_id'],
        },
      ],
      group: ['user_id'],
      order: [["user_id", "DESC"]],
    });
    return await responseSuccess(req, res, "Role wise Data", userData);
  } catch (error) {
    console.log("error", error)
    return await responseError(req, res, "something went wrong");
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    let userData = [];

    // for specific user detail
    if (req.query.id) {
      userData = await req.config.users.findOne({
        where: {
          user_code: req.query.id,
          
        },
        attributes: {
          exclude: [
            "password",
            "password_reset_token",
            "password_reset_expires",
            "deletedAt",
          ],
        },
        include: [
          {
            model: req.config.usersProfiles,
            include: [
              {
                model: req.config.divisions,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.departments,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.designations,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
            ],
          },
          {
            model: req.config.user_role,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.country,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.states,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.city,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.users,
            as: 'reportToUser',
            attributes: ['user_id','user']
          },
          {
            model: req.config.userPlatform,
            required: false
          }
        ],
      });

      // check if user has master role permission

      let RolePermissionData = await req.config.sequelize.query(
        `SELECT m1.menu_id,
               m1.menu_name,
               m1.parent_id,
               m1.menu_order,
               m1.is_active,
               m1.link,
               r1.permission_id,
               r1.role_id,
               m1.is_task,
               m1.icon_path,
               IFNULL(r1.actions, 0) as "actions"
           FROM
               db_menus AS m1
               LEFT JOIN db_role_permissions AS r1 ON m1.menu_id = r1.menu_id AND r1.role_id = ${req.user.role_id} where m1.is_active = true`,
        {
          type: QueryTypes.SELECT,
        }
      );

      AllData = RolePermissionData;
      const rootNodes = AllData.filter((item) => item.menu_id == 173);
      let dashNavArr = [];
      const tree = rootNodes.map((rootNode) => {
        if (req.user.isDB && rootNode.is_active == 1) {
          dashNavArr.push(rootNode);
        } else {
          if (rootNode.actions == 1) {
            dashNavArr.push(rootNode);
          }
        }
        if (dashNavArr.length > 0) {
          return dashNavArr;
        } else {
          dashNavArr.concat(
            buildTree(req.user.isDB, rootNode.menu_id, dashNavArr)
          );
        }
      });

      dashNavArr.length > 0
        ? (userData.dataValues.hasMaster = true)
        : (userData.dataValues.hasMaster = false);
    } else {
      // if mode == ul and login by admin then all user will shown except the admin
      let whereCaluse = { doc_verification: 2 };
      if (req.query.mode && req.query.mode == "ul") {
        whereCaluse = {
          isDB: false,
          doc_verification: 2,
        };
      }

      // if not login in by admin the all user list will be shown that report to current user
      if (!req.user.isDB) {
        whereCaluse = {
          doc_verification: 2,
          isDB: false,
          [Op.or]: [
            { user_id: req.user.user_id },
            { report_to: req.user.user_id },
          ],
        };
      }

      userData = await req.config.users.findAll({
        where: whereCaluse,
        attributes: {
          exclude: [
            "password",
            "password_reset_token",
            "password_reset_expires",
            "deletedAt",
          ],
        },
        include: [
          {
            model: req.config.usersProfiles,
            include: [
              {
                model: req.config.divisions,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.departments,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.designations,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
            ],
          },
          {
            model: req.config.user_role,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.country,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.states,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.city,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.users,
            as: 'reportToUser',
            attributes: ['user_id','user']
          },
        ],
        order: [["user_id", "DESC"]],
      });
    }

    return await responseSuccess(req, res, "All Users", userData);
  } catch (error) {
    console.log("err", error)
    return await responseError(req, res, "something went wrong");
  }
};

exports.updateUser = async (req, res) => {
  try {
    let dbUserData = req.body;
    let message = 'user data updated'

    // find user in admin
    let userData = await db.clients.findOne({
      where: {
        user_code: dbUserData.user_code,
      },
    });

    // if user not found send error user not found
    if (!userData) {
      await req.config.sequelize.close();
      return res.status(400).json({ status: 400, message: "user not found" });
    }

    // if password then hash it
    if (dbUserData.password) {
      dbUserData.password = await bcrypt.hash(dbUserData.password, 10);
    }


    // find user the update its profile
    let userDataInDB = await req.config.users.findOne({
      where: {
        user_code: dbUserData.user_code,
      },
    });

    if(dbUserData.report_to && userDataInDB.report_to != dbUserData.report_to) {
      const user = await req.config.users.findOne({
        where: {
          user_id: dbUserData.report_to,
        },
      });

      message = `The Channel Partner's request has been successfully Assigned to  ${user.user} ${user.user_l_name || ''} `
    }

    // update user
    await userDataInDB.update(dbUserData);

    await req.config.usersProfiles.update(dbUserData, {
      where: {
        user_id: userDataInDB.user_id,
      },
    });

    // change user id according to admin db  and then update admin db

    dbUserData.user_id = userData.user_id;
    await db.clients.update(dbUserData, {
      where: {
        user_code: dbUserData.user_code,
      },
    });

    
    

    // if accept onboarding user
    if(userData.doc_verification !== dbUserData.doc_verification && dbUserData.doc_verification == 2){
      
      const resetToken = crypto.randomBytes(32).toString("hex");
      let passwordResetToken = crypto
        .createHash("sha256")
        .update(resetToken)
        .digest("hex");
  
      await userData.update({
        password_reset_token: passwordResetToken,
        password_reset_expires: moment(new Date()).add(1, "d").toDate(),
      });
  
      await userData.save();
      const resetLink = `${req.admin.client_url}/CHANNEL/ResetViaMail?tkn=u$34${passwordResetToken}`;
      const htmlTemplatePath = path.join(
        __dirname,
        "..",
        "mail",
        "cp",
        "resetPassword.html"
      );
      const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
      const htmlContent = htmlTemplate.replace(
        "{{resetLink}}",
        resetLink
      );
      option = {
        email: userData.email,
        subject: "Kloud Mart",
        message: htmlContent,
      };

      await sendEmail(option);
      message = `The Channel Partner's request has been successfully Accepted`
    }

     // if reject onboarding user
    if (userData.doc_verification !== dbUserData.doc_verification && dbUserData.doc_verification == 3) {
      const htmlTemplatePath = path.join(
        __dirname,
        "..",
        "mail",
        "cp",
        "reject.html"
      );
      const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
      const htmlContent = htmlTemplate.replace(
        "{{reject_reason}}",
        dbUserData.reject_reason
      );
      option = {
        email: userData.email,
        subject: "Kloud Mart",
        message: htmlContent,
      };

      await sendEmail(option);
      message = `The Channel Partner's request has been successfully Rejected`
    }

    // close connection
    await req.config.sequelize.close();
    return res.status(200).json({ status: 200, message });
  } catch (error) {
    console.log("error", error)
    await req.config.sequelize.close();
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    let user_code = req.query.id;
    let userData = await db.clients.findOne({
      where: {
        user_code: user_code,
      },
    });

    if (!userData) {
      await req.config.sequelize.close();
      return res.status(400).json({ status: 400, message: "user not found" });
    }

    await db.clients.destroy({
      where: {
        user_code: user_code,
      },
    });

    await req.config.users.destroy({
      where: {
        user_code: user_code,
      },
    });
    return res
      .status(200)
      .json({ status: 200, message: "user deleted successfully", data: null });
  } catch (error) {
    await req.config.sequelize.close();
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong" });
  }
};

exports.getOwnerList = async (req, res) => {
  try {
    let userData = await req.config.users.findAll({
      where: {
        isDB: false,
        [Op.or]: [
          { user_id: req.user.user_id },
          { report_to: req.user.user_id },
        ],
      },
      attributes: {
        exclude: [
          "password",
          "password_reset_token",
          "password_reset_expires",
          "deletedAt",
        ],
      },
    });

    return await responseSuccess(req, res, "Owner list", userData);
  } catch (error) {
    await req.config.sequelize.close();
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong", data: { error } });
  }
};

exports.sendOtp = async (req, res) => {
  try {
    const email = req.body.email;
    if (!email) {
      return res.status(400).json({
        status: 400,
        message: "Please provide email for forgot password",
        data: null,
      });
    }
    const user = await db.clients.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({
        status: false,
        message: "No user found with that email",
      });
    }

    const opt =  randomSixCodeGenrator()

    await user.update({
      user_verify_otp: opt,
    });

    await user.save();
    const htmlTemplatePath = path.join(
      __dirname,
      "..",
      "mail",
      "cp",
      "sendotp.html"
    );

    const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
    const htmlContent = htmlTemplate.replace("{{OTP}}", opt);
    let option = {
      email: email,
      subject: "OTP verification for password reset",
      message: htmlContent,
    };
    await sendEmail(option);
    return res.status(200).json({
      status: 200,
      token: opt,
      message: `Mail sent to your mail id ${user.email}`,
    });

  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong", data: error });
  }
};


exports.otpVerification = async (req, res) => {
  try {
    const {email, otp} = req.body;
    if (!email) {
      return res.status(400).json({
        status: 400,
        message: "Please provide email for forgot password",
        data: null,
      });
    }
    const user = await db.clients.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({
        status: false,
        message: "No user found with that email",
      });
    }

    if (user.otp === '') {
      return res.status(200).json({
        status: false,
        message: "verification process isnt initiated",
      });
    }

    if (user.user_verify_otp !== otp) {
      return res.status(200).json({
        status: false,
        message: "incorrect OTP",
      });
    }

    const resetToken = crypto.randomBytes(32).toString("hex");
    let passwordResetToken = crypto
      .createHash("sha256")
      .update(resetToken)
      .digest("hex");

    await user.update({
      password_reset_token: passwordResetToken,
      password_reset_expires: moment(new Date()).add(1, "d").toDate(),
    });

    await user.save();
    return res.status(200).json({
      status: 200,
      message: `succesfully verified`,
    });
    
  } catch (error) {
    console.log(error)
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong", data: error });
  }
};

exports.resetChannelPassword = async (req, res) => {
  try {
    let body = req.body;
    if (!body.password) {
      return res.status(400).json({
        status: 400,
        message: "Please enter password",
      });
    }

    let user = await db.clients.findOne({
      where: { email: body.email },
    });


    if (!user) {
      return res.status(400).json({
        status: 400,
        message: "Unable to found user",
      });
    }

    if (!user.password_reset_expires) {
      return res.status(400).json({
        status: 400,
        message: "toekn expire already",
      });
    }

    const tokenExpiry = new Date(user.password_reset_expires);
    const currentDateTime = new Date();

    if (currentDateTime > tokenExpiry) {
      return res.status(400).json({
        status: 400,
        message: "token is already expired",
      });
    }




    let newPassword = body.password;
    let newSavePassword = await bcrypt.hash(newPassword, 10);
    user.update({
      password: newSavePassword,
      password_reset_token: null,
      user_verify_otp: null,
      password_reset_expires: new Date(),
    });
    user.save();
    let userDB = await first(user.db_name);

    await userDB.users.update(
      { password: newSavePassword },
      {
        where: {
          user_code: user.user_code,
        },
      }
    );
    userDB.sequelize.close();
    return res.status(200).json({
      status: 200,
      message: "password changed",
      data: user,
    });
  } catch (error) {
    console.log(error)
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong", data: error });
  }
};



exports.forgotpassword = async (req, res) => {
  try {
    const email = req.body.email;
    if (!email) {
      return res.status(400).json({
        status: 400,
        message: "Please provide email for forgot password",
        data: null,
      });
    }
    const user = await db.clients.findOne({ where: { email } });

    if (!user) {
      return res.status(404).json({
        status: false,
        message: "No user found with that email",
      });
    }

    const resetToken = crypto.randomBytes(32).toString("hex");
    let passwordResetToken = crypto
      .createHash("sha256")
      .update(resetToken)
      .digest("hex");

    await user.update({
      password_reset_token: passwordResetToken,
      password_reset_expires: moment(new Date()).add(1, "d").toDate(),
    });

    await user.save();

    const resetLink = `${req.admin.client_url}/ChangePassword?tkn=u$34${passwordResetToken}`;
    const htmlTemplatePath = path.join(
      __dirname,
      "..",
      "mail",
      "cp",
      "forgot.html"
    );

    const htmlTemplate = fs.readFileSync(htmlTemplatePath, "utf-8");
    const htmlContent = htmlTemplate.replace("{{resetLink}}", resetLink);
    let option = {
      email: email,
      subject: "Your passowrd reset token only 1 day ",
      message: htmlContent,
    };
    await sendEmail(option);
    return res.status(200).json({
      status: 200,
      token: passwordResetToken,
      message: `Mail sent to your mail id ${user.email}`,
    });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong", data: error });
  }
};

exports.resetPassword = async (req, res) => {
  try {
    let body = req.body;
    if (!body.password) {
      return res.status(400).json({
        status: 400,
        message: "Please enter password",
      });
    }

    let user = await db.clients.findOne({
      where: { password_reset_token: body.token },
    });
    if (!user) {
      return res.status(400).json({
        status: 400,
        message: "Unable to found user",
      });
    }

    let newPassword = body.password;
    let newSavePassword = await bcrypt.hash(newPassword, 10);
    user.update({
      password: newSavePassword,
      password_reset_token: null,
      user_verify_otp: null,
      password_reset_expires: new Date(),
    });
    user.save();
    let userDB = await first(user.db_name);

    await userDB.users.update(
      { password: newSavePassword },
      {
        where: {
          user_code: user.user_code,
        },
      }
    );
    userDB.sequelize.close();
    return res.status(200).json({
      status: 200,
      message: "password changed",
      data: user,
    });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "something went wrong", data: error });
  }
};

exports.registerBulkUser = async (req, res) => {
  try {
    let userData = req.body;
    let depData = await req.config.departments.findAll();
    let divData = await req.config.divisions.findAll();
    let desData = await req.config.designations.findAll();
    let reportData = await req.config.users.findAll();

    let clientAdmin = await db.clients.findOne({
      where: {
        db_name: req.user.db_name,
        isDB: true,
      },
    });

    const count = await req.config.users.count({
      where: {
        isDB: false,
      },
    });

    if (count >= clientAdmin.no_of_license) {
      return await responseError(
        req,
        res,
        "cannot add more user, user count exceed the license count"
      );
    }

    if (
      parseInt(count) + parseInt(userData.length) >=
      clientAdmin.no_of_license
    ) {
      return await responseError(
        req,
        res,
        `can add bulk user ${
          parseInt(count) +
          parseInt(userData.length) -
          clientAdmin.no_of_license
        }`
      );
    }

    await Promise.all(
      userData.map(async (item, i) => {
        item.user = item["User Name"];
        item.user_code = randomCodeGenrator("USER");
        item.email = item["Email"] !== "" ? item["Email"] : null;
        item.contact_number =
          item["Contact number"] !== "" ? item["Contact number"] : null;
        (item.password = await bcrypt.hash("12345", 10)),
          (item.db_name = clientAdmin.db_name);
        item.country_id = 1;
        item.address = item["Address"] !== "" ? item["Address"] : null;
        item.pincode = item["Pincode"] !== "" ? item["Pincode"] : null;
        item.subscription_start_date = clientAdmin.subscription_start_date;
        item.subscription_end_date = clientAdmin.subscription_end_date;

        // divison map
        if (item["Divison"] !== "") {
          await Promise.all(
            divData.map((el, i) => {
              if (item["Divison"] == el.dataValues.divison) {
                item.div_id = el.dataValues.div_id;
                return el;
              }
            })
          );

          if (item.div_id === undefined) {
            item.div_id = null;
          }
        } else {
          item.div_id = null;
        }

        if (item["Department"] !== "") {
          await Promise.all(
            depData.map((el, i) => {
              if (item["Department"] == el.dataValues.department) {
                item.dep_id = el.dataValues.dep_id;
                return el;
              }
            })
          );

          if (item.dep_id === undefined) {
            item.dep_id = null;
          }
        } else {
          item.dep_id = null;
        }

        if (item["Designation"] !== "") {
          await Promise.all(
            desData.map((el, i) => {
              if (item["Designation"] == el.dataValues.designation) {
                item.des_id = el.dataValues.des_id;
                return el;
              }
            })
          );

          if (item.des_id === undefined) {
            item.des_id = null;
          }
        } else {
          item.des_id = null;
        }

        if (item["Report To"] !== "") {
          await Promise.all(
            reportData.map((el, i) => {
              if (item["Report To"] == el.dataValues.user) {
                item.report_to = el.dataValues.user_id;
                return el;
              }
            })
          );

          if (item.report_to === undefined) {
            item.report_to = null;
          }
        } else {
          item.report_to = null;
        }

        await db.clients.create(item);
        let dbUserData = await req.config.users.create(item);
        item.user_id = dbUserData.user_id;
        await req.config.usersProfiles.create(item);
        return item;
      })
    );

    return await responseSuccess(req, res, "Owner list", userData);
  } catch (error) {
    return await responseError(req, res, "Error", error);
  }
};

exports.registrationTokenVerification = async (req, res) => {
  try {
    const { token } = req.body;
    const decoded = await promisify(jwt.verify)(token, process.env.CLIENT_SECRET);
    const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
    if (decoded && decoded.exp < currentTime)
      return res
        .status(400)
        .json({ status: 400, message: "Token has expired" });
    //
    // console.log('decoded.db_name',decoded.db_name);
    let ud = await first(decoded.db_name, req, res);

    if (!ud)
      return res
        .status(400)
        .json({ status: 400, message: "Database not found" });

    let user = await ud.users.findOne({
      where: { user_id: decoded.id },
      include: [
        {
          model: ud.usersProfiles,
        },
      ],
    });

    if (!user)
      return res
        .status(400)
        .json({ status: 400, message: "No  data found of channel partner" });
    // return res.send(user);
    return res
      .status(200)
      .json({ status: 200, message: "User token verified.", data: user });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "Error", error: error });
  }
};

exports.cpCompleteRegistration = async (req, res) => {
  try {
    const { token, name, mobile, user_l_name, gst, organisation, address, city_id, state_id } = req.body;
    const decoded = await promisify(jwt.verify)(token, process.env.CLIENT_SECRET);
    const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
    if (decoded && decoded.exp < currentTime)
      return res
        .status(400)
        .json({ status: 400, message: "Token has expired" });
    //
    // console.log('decoded.db_name',decoded.db_name);
    let ud = await first(decoded.db_name, req, res);
    if (!ud)
      return res
        .status(400)
        .json({ status: 400, message: "Database not found" });

    let user = await ud.users.findByPk(decoded.id);
    if (!user)
      return res
        .status(400)
        .json({ status: 400, message: "No  data found of channel partner" });
    if (!req.files || !req.files.aadhar)
      return res
        .status(400)
        .json({ status: 400, message: "Aadhar is required." });
    if (!req.files || !req.files.pan)
      return res.status(400).json({ status: 400, message: "Pan is required." });
    if (!req.files || !req.files.rera)
      return res
        .status(400)
        .json({ status: 400, message: "Rera is required." });

    var aadhar = "";
    var pan = "";
    var rera = "";
    var cheque = "";

    if (req.files && req.files.aadhar) {
      aadharName = await fileUpload.imageExport(req, res, "adh", "aadhar");
      aadhar = aadharName;
    }
    if (req.files && req.files.pan) {
      panName = await fileUpload.imageExport(req, res, "pan", "pan");
      pan = panName;
    }
    if (req.files && req.files.rera) {
      reraName = await fileUpload.imageExport(req, res, "rera", "rera");
      rera = reraName;
    }
    if (req.files && req.files.cheque) {
      chequeName = await fileUpload.imageExport(req, res, "cheque", "cheque");
      cheque = chequeName;
    }

    user.user = name;
    user.contact_number = mobile;
    user.doc_verification = 1;

    let updateData = {};
    updateData.aadhar_file = aadhar;
    updateData.pan_file = pan;
    updateData.rera_file = rera;
    updateData.c_cheque_file = cheque;
    updateData.user_id = decoded.id;
    updateData.user_l_name = user_l_name;
    updateData.gst = gst;
    updateData.organisation = organisation;
    updateData.address = address;
    updateData.country_id = 101;
    updateData.city_id = city_id;
    updateData.state_id = state_id;

    let userProfile = await ud.usersProfiles.findOne({
      where: {
        user_id: decoded.id,
      },
    });

    if (userProfile) {
      // Update existing record
      const userDATA = await user.update(updateData);
      
      userProfile = await ud.usersProfiles.update(updateData, {
        where: {
          user_id: decoded.id,
        },
      });
    } else {
      // Create new record
      userProfile = await ud.usersProfiles.create(updateData);
    }
    // First profile save then save user
    await user.save();

    userData = await ud.users.findOne({
      attributes: [
        "user_id",
        "user",
        "contact_number",
        "db_name",
        "user_code",
        "role_id",
        "doc_verification",
        "reject_reason",
      ],
      where: {
        user_id: decoded.id,
      },
      include: [
        {
          model: ud.usersProfiles,
        },
      ],
    });

    return res.status(200).json({
      status: 200,
      message: "Channel partner document uploaded.",
      data: userData,
    });
  } catch (error) {
    return res
      .status(400)
      .json({ status: 400, message: "Error", error: error });
  }
};

exports.getPendingVerificationUser = async (req, res) => {
  try {
    let usersData = null;
    let whereClause = {
      doc_verification: {
        [Op.or]: [0, 1, 3],
      },
    };
    if (req.query.id) {
      whereClause.user_code = req.query.id;
      usersData = await req.config.users.findOne({
        where: whereClause,
        attributes: {
          exclude: [
            "password",
            "password_reset_token",
            "password_reset_expires",
            "deletedAt",
          ],
        },
        include: [
          {
            model: req.config.usersProfiles,
            include: [
              {
                model: req.config.divisions,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.departments,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.designations,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
            ],
          },
          {
            model: req.config.user_role,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.country,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.states,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.city,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
        ],
      });
    } else {
      usersData = await req.config.users.findAll({
        where: {
          doc_verification: {
            [Op.or]: [0, 1, 3],
          },
        },
        attributes: {
          exclude: [
            "password",
            "password_reset_token",
            "password_reset_expires",
            "deletedAt",
          ],
        },
        include: [
          {
            model: req.config.usersProfiles,
            include: [
              {
                model: req.config.divisions,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.departments,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
              {
                model: req.config.designations,
                attributes: {
                  exclude: ["createdAt", "updatedAt", "deletedAt"],
                },
              },
            ],
          },
          {
            model: req.config.user_role,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.country,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.states,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
          {
            model: req.config.city,
            attributes: {
              exclude: ["createdAt", "updatedAt", "deletedAt"],
            },
          },
        ],
        order: [["user_id", "DESC"]],
      });
    }

    return responseSuccess(
      req,
      res,
      "User list fetch successfully.",
      usersData
    );
  } catch (error) {
    console.log("error", error);
    return res
      .status(400)
      .json({ status: 400, message: "Error", error: error });
  }
};
